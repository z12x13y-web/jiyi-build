import 'package:flutter/material.dart';

import 'app/app_dependencies.dart';
import 'app/autofill_app.dart';
import 'app/pine_vault_app.dart';
import 'data/services/app_preferences_service.dart';
import 'data/services/native_autofill_service.dart';
import 'ui/core/background_image_cache.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // 读取本地偏好（背景、自动填充排除列表）。
  await AppPreferences.instance.load();
  // 关键：在 runApp 之前把内置背景解码好，保证第一帧就是完整背景。
  await BackgroundImageCache.loadDefault();
  final dependencies = await AppDependencies.create();
  await dependencies.vaultViewModel.initialize();
  runApp(
    PineVaultApp(
      vaultViewModel: dependencies.vaultViewModel,
      webDavSettingsViewModel: dependencies.webDavSettingsViewModel,
      backupViewModel: dependencies.backupViewModel,
    ),
  );
}

@pragma('vm:entry-point')
Future<void> autofillEntryPoint() async {
  WidgetsFlutterBinding.ensureInitialized();
  final request = await NativeAutofillAuth.request();
  final dependencies = await AppDependencies.create(enableVaultSync: true);
  await dependencies.vaultViewModel.initialize();
  runApp(
    AutofillApp(
      vaultViewModel: dependencies.vaultViewModel,
      request: request,
    ),
  );
}
