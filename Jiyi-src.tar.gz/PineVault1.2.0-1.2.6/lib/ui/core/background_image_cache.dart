import 'dart:ui' as ui;

import 'package:flutter/services.dart';

/// 内置默认背景的资源路径。
const String kDefaultBackgroundAsset =
    'assets/backgrounds/default_background.jpg';

/// 首帧背景图缓存。
///
/// 关键点：在 `runApp` 之前就把它解码成 [ui.Image]，页面用 [RawImage] 直接绘制。
/// 这样 Flutter 的第一帧就带着背景，不会出现「先白后图」的闪烁。

class BackgroundImageCache {
  BackgroundImageCache._();

  static ui.Image? defaultImage;

  static Future<void> loadDefault() async {
    if (defaultImage != null) return;
    try {
      final data = await rootBundle.load(kDefaultBackgroundAsset);
      final bytes = data.buffer.asUint8List(
        data.offsetInBytes,
        data.lengthInBytes,
      );
      // 按 1440 宽解码：避免整张原图每帧缩放导致掉帧；失败则退回原尺寸。
      ui.Codec codec;
      try {
        codec = await ui.instantiateImageCodec(bytes, targetWidth: 1440);
      } catch (_) {
        codec = await ui.instantiateImageCodec(bytes);
      }
      final frame = await codec.getNextFrame();
      defaultImage = frame.image;
    } catch (_) {
      // 加载失败时保持为 null，界面侧会退回 Image.asset。
    }
  }
}
