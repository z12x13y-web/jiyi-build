part of 'vault_home_screen.dart';

Future<void> _sync(BuildContext context, VaultViewModel viewModel) async {
  final succeeded = await viewModel.sync();
  if (!context.mounted) return;
  final message = succeeded ? viewModel.syncMessage : viewModel.errorMessage;
  showAppMessage(context, message ?? '同步失败，请重试');
}
