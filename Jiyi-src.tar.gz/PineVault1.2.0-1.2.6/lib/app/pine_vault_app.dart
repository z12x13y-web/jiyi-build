import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../ui/features/onboarding/setup_screen.dart';
import '../ui/features/backup/backup_view_model.dart';
import '../ui/features/settings/webdav_settings_view_model.dart';
import '../ui/features/unlock/unlock_screen.dart';
import '../ui/features/vault/vault_home_screen.dart';
import '../ui/features/vault/vault_view_model.dart';
import '../data/services/app_preferences_service.dart';
import '../ui/core/app_feedback.dart';
import '../ui/core/app_theme.dart';
import '../ui/core/pine_vault_background_layer.dart';

class PineVaultApp extends StatefulWidget {
  const PineVaultApp({
    super.key,
    required this.vaultViewModel,
    required this.webDavSettingsViewModel,
    required this.backupViewModel,
    DateTime Function()? now,
  }) : _now = now ?? DateTime.now;

  final VaultViewModel vaultViewModel;
  final WebDavSettingsViewModel webDavSettingsViewModel;
  final BackupViewModel backupViewModel;
  final DateTime Function() _now;

  @override
  State<PineVaultApp> createState() => _PineVaultAppState();
}

class _PineVaultAppState extends State<PineVaultApp>
    with WidgetsBindingObserver {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  Timer? _backgroundLockTimer;
  DateTime? _backgroundedAt;
  bool _lockedForBackgroundTimeout = false;
  late VaultAppState _lastVaultState;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _lastVaultState = widget.vaultViewModel.state;
    widget.vaultViewModel.addListener(_handleVaultStateChanged);
  }

  @override
  void dispose() {
    widget.vaultViewModel.removeListener(_handleVaultStateChanged);
    WidgetsBinding.instance.removeObserver(this);
    _backgroundLockTimer?.cancel();
    super.dispose();
  }

  /// 锁定后把弹出的菜单 / 详情页 / 设置子页全部收回，
  /// 避免它们盖在解锁页上（1.1.2 修复解锁界面与其他界面重叠）。
  void _handleVaultStateChanged() {
    final state = widget.vaultViewModel.state;
    final justLocked =
        state == VaultAppState.locked &&
        _lastVaultState != VaultAppState.locked;
    _lastVaultState = state;
    if (!justLocked) return;
    dismissAppMessage();
    FocusManager.instance.primaryFocus?.unfocus();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _navigatorKey.currentState?.popUntil((route) => route.isFirst);
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.hidden:
        _scheduleBackgroundLock(canLockImmediately: true);
      case AppLifecycleState.inactive:
        _scheduleBackgroundLock(canLockImmediately: false);
      case AppLifecycleState.resumed:
        _handleResumed();
      case AppLifecycleState.detached:
        break;
    }
  }

  void _scheduleBackgroundLock({required bool canLockImmediately}) {
    if (!_isVaultOpen) return;
    final int seconds = AppPreferences.instance.autoLockSeconds;
    if (seconds < 0) {
      _backgroundLockTimer?.cancel();
      return;
    }
    _backgroundedAt ??= widget._now();
    _backgroundLockTimer?.cancel();
    if (seconds == 0) {
      // 「立即」只在真正退到后台（paused / hidden）时锁；
      // 下拉通知栏这类 inactive 不应该马上锁屏。
      if (!canLockImmediately) return;
      _lockedForBackgroundTimeout = true;
      widget.vaultViewModel.lock(automaticDeviceUnlock: false);
      return;
    }
    final delay = Duration(seconds: seconds);
    _backgroundLockTimer = Timer(delay, () {
      final backgroundedAt = _backgroundedAt;
      if (backgroundedAt == null ||
          widget._now().difference(backgroundedAt) < delay) {
        return;
      }
      if (_isVaultOpen) {
        _lockedForBackgroundTimeout = true;
        widget.vaultViewModel.lock(automaticDeviceUnlock: false);
      }
    });
  }

  void _handleResumed() {
    final backgroundedAt = _backgroundedAt;
    _backgroundedAt = null;
    _backgroundLockTimer?.cancel();
    _backgroundLockTimer = null;
    if (_lockedForBackgroundTimeout) {
      _lockedForBackgroundTimeout = false;
      widget.vaultViewModel.allowAutomaticDeviceUnlock();
      return;
    }
    final int seconds = AppPreferences.instance.autoLockSeconds;
    if (backgroundedAt != null &&
        seconds > 0 &&
        widget._now().difference(backgroundedAt) >=
            Duration(seconds: seconds) &&
        _isVaultOpen) {
      widget.vaultViewModel.lock();
    }
  }

  bool get _isVaultOpen => switch (widget.vaultViewModel.state) {
    VaultAppState.unlocked ||
    VaultAppState.saving ||
    VaultAppState.syncing => true,
    _ => false,
  };

  @override
  Widget build(BuildContext context) {
    final windowsFontFamily = defaultTargetPlatform == TargetPlatform.windows
        ? 'Microsoft YaHei UI'
        : null;
    final lightScheme = buildPineVaultColorScheme(Brightness.light);
    final darkScheme = buildPineVaultColorScheme(Brightness.dark);
    return MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: widget.vaultViewModel),
        ChangeNotifierProvider.value(value: widget.webDavSettingsViewModel),
        ChangeNotifierProvider.value(value: widget.backupViewModel),
      ],
      child: MaterialApp(
        navigatorKey: _navigatorKey,
        title: '记忆',
        debugShowCheckedModeBanner: false,
        themeMode: ThemeMode.light,
        theme: ThemeData(
          colorScheme: lightScheme,
          fontFamily: windowsFontFamily,
          useMaterial3: true,
          // 页面底色交给 PineVaultBackgroundLayer（自定义背景需要）。
          scaffoldBackgroundColor: Colors.transparent,
          // 顶栏也透明，露出背景层，避免推入页面时出现一条白色顶栏。
          // 页面转场改为无底色的滑动（默认 zoom 转场会画一层不透明底色，切页闪白）。
          pageTransitionsTheme: const PageTransitionsTheme(
            builders: <TargetPlatform, PageTransitionsBuilder>{
              TargetPlatform.android: _FadeTransitionsBuilder(),
              TargetPlatform.iOS: _FadeTransitionsBuilder(),
              TargetPlatform.macOS: _FadeTransitionsBuilder(),
            },
          ),
          // Material 的默认 canvas 色是白，改成透明，避免盖住背景。
          canvasColor: Colors.transparent,
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.transparent,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            scrolledUnderElevation: 0,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: lightScheme.surfaceContainerLow,
            isDense: true,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(14)),
              borderSide: BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(14)),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(14)),
              borderSide: BorderSide(color: Colors.black, width: 1.5),
            ),
          ),
        ),
        darkTheme: ThemeData(
          colorScheme: darkScheme,
          fontFamily: windowsFontFamily,
          useMaterial3: true,
          // 页面底色交给 PineVaultBackgroundLayer（自定义背景需要）。
          scaffoldBackgroundColor: Colors.transparent,
          // 顶栏也透明，露出背景层，避免推入页面时出现一条白色顶栏。
          // 页面转场改为无底色的滑动（默认 zoom 转场会画一层不透明底色，切页闪白）。
          pageTransitionsTheme: const PageTransitionsTheme(
            builders: <TargetPlatform, PageTransitionsBuilder>{
              TargetPlatform.android: _FadeTransitionsBuilder(),
              TargetPlatform.iOS: _FadeTransitionsBuilder(),
              TargetPlatform.macOS: _FadeTransitionsBuilder(),
            },
          ),
          // Material 的默认 canvas 色是白，改成透明，避免盖住背景。
          canvasColor: Colors.transparent,
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.transparent,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            scrolledUnderElevation: 0,
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: darkScheme.surfaceContainerLow,
            isDense: true,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 14,
            ),
            border: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(14)),
              borderSide: BorderSide.none,
            ),
            enabledBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(14)),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: const BorderRadius.all(Radius.circular(14)),
              borderSide: BorderSide(color: Colors.black, width: 1.5),
            ),
          ),
        ),
        builder: (context, child) =>
            PineVaultBackgroundLayer(child: child ?? const SizedBox.shrink()),
        home: const _AppRouter(),
      ),
    );
  }
}

class _AppRouter extends StatefulWidget {
  const _AppRouter();

  @override
  State<_AppRouter> createState() => _AppRouterState();
}

class _AppRouterState extends State<_AppRouter> {
  @override
  Widget build(BuildContext context) {
    return Consumer<VaultViewModel>(
      builder: (context, viewModel, _) {
        return switch (viewModel.state) {
          VaultAppState.initializing => const _LoadingScreen(),
          VaultAppState.noVault ||
          VaultAppState.creating ||
          VaultAppState.restoring => SetupScreen(
            busy:
                viewModel.state == VaultAppState.creating ||
                viewModel.state == VaultAppState.restoring,
            errorMessage: viewModel.errorMessage,
            onCreate: viewModel.createVault,
            onRestore: viewModel.restore,
          ),
          VaultAppState.locked || VaultAppState.unlocking => UnlockScreen(
            busy: viewModel.state == VaultAppState.unlocking,
            errorMessage: viewModel.errorMessage,
            onUnlock: viewModel.unlock,
            deviceUnlockEnabled: viewModel.deviceUnlockEnabled,
            onDeviceUnlock: viewModel.unlockWithDevice,
            automaticDeviceUnlock: viewModel.automaticDeviceUnlock,
          ),
          VaultAppState.unlocked ||
          VaultAppState.saving ||
          VaultAppState.syncing => const VaultHomeScreen(),
        };
      },
    );
  }
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Center(child: CircularProgressIndicator()));
  }
}

/// 极短淡入转场：页面自带不透明背景，淡入期间旧页面已被盖住，不会叠图。
class _FadeTransitionsBuilder extends PageTransitionsBuilder {
  const _FadeTransitionsBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    return FadeTransition(
      opacity: animation.drive(CurveTween(curve: Curves.easeOut)),
      child: child,
    );
  }
}
