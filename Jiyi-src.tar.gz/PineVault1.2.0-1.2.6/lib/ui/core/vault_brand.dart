import 'package:flutter/material.dart';

class VaultBrand extends StatelessWidget {
  const VaultBrand({
    super.key,
    this.compact = false,
    this.showIcon = true,
    this.showTitle = true,
    this.outlined = false,
  });

  final bool compact;

  /// 是否显示盾牌图标。
  final bool showIcon;

  /// 是否在图标右侧显示「记忆」标题；关闭后整块只剩图标，可配合 Align 居中。
  final bool showTitle;

  /// 是否给图标底板加描边，描边颜色与输入框默认描边一致（colorScheme.outline）。
  final bool outlined;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final badge = Container(
      width: compact ? 40 : 56,
      height: compact ? 40 : 56,
      decoration: BoxDecoration(
        color: scheme.primaryContainer,
        borderRadius: BorderRadius.circular(compact ? 12 : 18),
        border: outlined
            ? Border.all(color: scheme.outline, width: 1)
            : null,
      ),
      child: Icon(
        Icons.shield_outlined,
        color: scheme.onPrimaryContainer,
        size: compact ? 24 : 32,
      ),
    );
    final title = Text(
      '记忆',
      style: compact
          ? Theme.of(context).textTheme.titleLarge
          : Theme.of(context).textTheme.headlineSmall,
    );

    if (!showIcon) return showTitle ? title : const SizedBox.shrink();
    if (!showTitle) return badge;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [badge, const SizedBox(width: 12), title],
    );
  }
}
