import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../data/services/app_preferences_service.dart';

/// 全屏背景层：底层纯色兜底；设置了「自定义背景」后，在其上绘制图片、
/// 半透明遮罩与模糊，再叠放页面内容。
///
/// 维护说明：
/// 1. 页面底色统一由本层绘制，所以 `app_theme.dart` 的
///    `scaffoldBackgroundColor` 必须保持 `Colors.transparent`；
/// 2. 各页 Scaffold / AppBar 不要再设不透明 `backgroundColor`，否则会盖住背景；
/// 3. 背景图片、遮罩浓度、模糊半径都由 `AppPreferences` 提供，改动后会通过
///    [ListenableBuilder] 立即重绘。
class PineVaultBackgroundLayer extends StatelessWidget {
  const PineVaultBackgroundLayer({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppPreferences.instance,
      builder: (context, _) {
        final prefs = AppPreferences.instance;
        final theme = Theme.of(context);
        final path = prefs.backgroundPath;
        final showImage = prefs.backgroundEnabled && path != null;
        final blur = prefs.backgroundBlur;
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            // 兜底底色：跟随明暗主题（浅色 = 页面底色，深色 = 深色页面底色）。
            ColoredBox(color: theme.colorScheme.surface),
            if (showImage)
              // RepaintBoundary：切页或局部重建时复用已绘制的背景，避免闪一下底色。
              RepaintBoundary(
                child: blur > 0
                    ? ImageFiltered(
                        imageFilter:
                            ui.ImageFilter.blur(sigmaX: blur, sigmaY: blur),
                        child: _BackgroundImage(path: path),
                      )
                    : _BackgroundImage(path: path),
              ),
            child,
          ],
        );
      },
    );
  }
}

class _BackgroundImage extends StatelessWidget {
  const _BackgroundImage({required this.path});

  final String path;

  /// 同一路径复用同一个 provider，并按 1080 宽解码：
  /// 大幅降低解码与模糊开销，避免切页时出现半秒级卡顿/白屏。
  static final Map<String, ImageProvider<Object>> _providers =
      <String, ImageProvider<Object>>{};

  ImageProvider<Object> get _provider => _providers.putIfAbsent(
        path,
        () => ResizeImage(FileImage(File(path)), width: 1080),
      );

  @override
  Widget build(BuildContext context) {
    return Image(
      image: _provider,
      fit: BoxFit.cover,
      filterQuality: FilterQuality.low,
      gaplessPlayback: true,
      errorBuilder: (context, error, stackTrace) => const SizedBox.shrink(),
    );
  }
}
