part of 'vault_home_screen.dart';

class _VaultList extends StatelessWidget {
  const _VaultList({
    required this.viewModel,
    required this.onOpenSync,
    required this.onOpenSettings,
    this.onItemTap,
    this.selectedItemId,
  });

  final VaultViewModel viewModel;
  final VoidCallback onOpenSync;
  final VoidCallback onOpenSettings;
  final ValueChanged<VaultItem>? onItemTap;
  final String? selectedItemId;

  @override
  Widget build(BuildContext context) {
    final items = viewModel.items;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
          child: TextField(
            key: const Key('vault-search'),
            onChanged: viewModel.setQuery,
            textInputAction: TextInputAction.search,
            // 按下键盘上的「搜索」后收起输入法，结果已在 onChanged 实时过滤。
            onSubmitted: (value) {
              viewModel.setQuery(value);
              FocusManager.instance.primaryFocus?.unfocus();
            },
            onTapOutside: (_) => FocusManager.instance.primaryFocus?.unfocus(),
            decoration: InputDecoration(
              hintText: '搜索名称或用户名',
              prefixIcon: const Icon(Icons.search_rounded),
              filled: true,
              fillColor: Theme.of(context).colorScheme.surfaceContainerLow,
              isDense: true,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 15,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(
                  // 1.2.2：去掉 alpha 稀释，用实色描边。
                  color: Theme.of(context).colorScheme.outlineVariant,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(
                  color: Theme.of(context).colorScheme.primary,
                  width: 1.5,
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
          child: Row(
            children: [
              Expanded(
                child: _VaultHeaderButton(
                  key: const Key('add-item'),
                  icon: Icons.add_rounded,
                  label: '新建密码',
                  onPressed: viewModel.busy
                      ? null
                      : () {
                          FocusManager.instance.primaryFocus?.unfocus();
                          _openEditor(context, viewModel);
                        },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _VaultHeaderButton(
                  icon: Icons.sync_rounded,
                  label: '同步',
                  onPressed: onOpenSync,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _VaultHeaderButton(
                  icon: Icons.tune_rounded,
                  label: '设置',
                  onPressed: onOpenSettings,
                ),
              ),
            ],
          ),
        ),
        if (viewModel.selectionMode)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Row(
              children: [
                Text('已选择 ${viewModel.selectedItemIds.length} 项'),
                const Spacer(),
                TextButton(
                  onPressed: viewModel.items.isEmpty
                      ? null
                      : viewModel.selectAllItems,
                  child: const Text('全选'),
                ),
                TextButton(
                  onPressed: viewModel.clearItemSelection,
                  child: const Text('清除'),
                ),
                IconButton(
                  tooltip: '退出多选',
                  onPressed: viewModel.exitSelectionMode,
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
          ),
        Expanded(
          child: items.isEmpty
              ? _EmptyVault(hasQuery: viewModel.query.isNotEmpty)
              : ListView.builder(
                  // 1.2.3：给悬浮底栏留出滚动余量，最后一行能滚到玻璃上方。
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  padding: EdgeInsets.only(
                    bottom: 24,
                  ),
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index];
                    final details = <String>[
                      item.username.isEmpty ? '未设置用户名' : item.username,
                      if (viewModel.showWebsites && item.urls.isNotEmpty)
                        item.urls.first,
                      if (viewModel.showWebsites &&
                          item.urls.isEmpty &&
                          item.appPackages.isNotEmpty)
                        item.appPackages.first,
                      if (viewModel.showPasswords)
                        item.password.isEmpty ? '未设置密码' : item.password,
                    ].join(' · ');
                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 4,
                      ),
                      elevation: 0,
                      color: item.id == selectedItemId
                          ? Theme.of(context).colorScheme.secondaryContainer
                          : Theme.of(context).colorScheme.surfaceContainerLow,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: BorderSide(
                          color: Theme.of(context).colorScheme.outlineVariant,
                        ),
                      ),
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          FocusManager.instance.primaryFocus?.unfocus();
                          if (viewModel.selectionMode) {
                            viewModel.toggleItemSelection(item.id);
                          } else if (onItemTap == null) {
                            _openViewer(context, viewModel, item);
                          } else {
                            onItemTap!(item);
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                          child: Row(
                            children: [
                              if (viewModel.selectionMode)
                                Padding(
                                  padding: const EdgeInsets.only(right: 2),
                                  child: Checkbox(
                                    value: viewModel.selectedItemIds.contains(
                                      item.id,
                                    ),
                                    visualDensity: VisualDensity.compact,
                                    materialTapTargetSize:
                                        MaterialTapTargetSize.shrinkWrap,
                                    onChanged: (_) =>
                                        viewModel.toggleItemSelection(item.id),
                                  ),
                                )
                              else
                                CircleAvatar(
                                  child: Text(
                                    item.title.isEmpty
                                        ? '?'
                                        : item.title[0].toUpperCase(),
                                  ),
                                ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item.title,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      details,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    if (viewModel.shouldShowTotp &&
                                        item.totp != null) ...[
                                      const SizedBox(height: 7),
                                      _HomeTotpLine(config: item.totp!),
                                    ],
                                  ],
                                ),
                              ),
                              if (item.favorite)
                                const Padding(
                                  padding: EdgeInsets.only(left: 8),
                                  child: Icon(Icons.star, color: Colors.amber),
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
        if (viewModel.selectionMode && viewModel.selectedItemIds.isNotEmpty)
          _BatchActionBar(viewModel: viewModel),
      ],
    );
  }
}

class _HomeTotpLine extends StatefulWidget {
  const _HomeTotpLine({required this.config});

  final TotpConfig config;

  @override
  State<_HomeTotpLine> createState() => _HomeTotpLineState();
}

class _HomeTotpLineState extends State<_HomeTotpLine> {
  static const _totpService = TotpService();
  Timer? _timer;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final code = _totpService.generate(widget.config, time: _now);
    final remaining = _totpService.remainingSeconds(widget.config, time: _now);
    final split = code.length ~/ 2;
    final displayCode = '${code.substring(0, split)} ${code.substring(split)}';
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 5, 4, 5),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer.withValues(alpha: 0.42),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(
            Icons.timer_outlined,
            size: 16,
            color: theme.colorScheme.primary,
          ),
          const SizedBox(width: 6),
          Text(
            displayCode,
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: LinearProgressIndicator(
              value: remaining / widget.config.period,
              minHeight: 3,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 7),
          Text('$remaining 秒', style: theme.textTheme.labelSmall),
          IconButton(
            tooltip: '复制动态验证码',
            visualDensity: VisualDensity.compact,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 30, minHeight: 28),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: code));
              if (context.mounted) showAppMessage(context, '动态验证码已复制');
            },
            icon: const Icon(Icons.copy_outlined, size: 16),
          ),
        ],
      ),
    );
  }
}

class _BatchActionBar extends StatelessWidget {
  const _BatchActionBar({required this.viewModel});

  final VaultViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      top: false,
      child: Container(
        // 1.2.3：悬浮底栏盖在页面内容之上，多选操作栏额外让出底栏高度。
        padding: EdgeInsets.fromLTRB(
          12,
          8,
          12,
          34,
        ),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          border: Border(
            top: BorderSide(color: theme.colorScheme.outlineVariant),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            IconButton(
              tooltip: '收藏/取消收藏',
              onPressed: viewModel.busy ? null : () => _toggleFavorite(context),
              icon: const Icon(Icons.star_outline),
            ),
            IconButton(
              tooltip: '移动分组',
              onPressed: viewModel.busy ? null : () => _moveGroup(context),
              icon: const Icon(Icons.drive_file_move_outlined),
            ),
            IconButton(
              tooltip: '复制全部',
              onPressed: () => _copyAll(context),
              icon: const Icon(Icons.copy_all_outlined),
            ),
            IconButton(
              tooltip: '删除',
              onPressed: viewModel.busy ? null : () => _delete(context),
              icon: Icon(Icons.delete_outline, color: theme.colorScheme.error),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _toggleFavorite(BuildContext context) async {
    final allFavorite = viewModel.selectedItems.every((item) => item.favorite);
    final ok = await viewModel.batchSetFavorite(!allFavorite);
    if (context.mounted && ok) {
      _showMessage(context, allFavorite ? '已取消收藏' : '已收藏');
    }
  }

  Future<void> _moveGroup(BuildContext context) async {
    final groupId = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.only(bottom: 12),
          children: [
            const ListTile(title: Text('移动到分组')),
            for (final group in viewModel.groups)
              ListTile(
                leading: const Icon(Icons.folder_outlined),
                title: Text(group.name),
                onTap: () => Navigator.pop(context, group.id),
              ),
          ],
        ),
      ),
    );
    if (groupId == null || !context.mounted) return;
    final ok = await viewModel.batchMoveToGroup(groupId);
    if (context.mounted && ok) _showMessage(context, '已移动到分组');
  }

  Future<void> _copyAll(BuildContext context) async {
    final selectedItems = viewModel.selectedItems;
    final selectedCount = selectedItems.length;
    final text = selectedItems
        .map(
          (item) => [
            '名称：${item.title}',
            '账号：${item.username}',
            '密码：${item.password}',
            '网站：${item.urls.isEmpty ? '' : item.urls.first}',
            if (item.appPackages.isNotEmpty) '应用：${item.appPackages.join(', ')}',
            '备注：${item.notes}',
            if (item.tags.isNotEmpty) '标签：${item.tags.join(', ')}',
          ].join('\n'),
        )
        .join('\n\n');
    await Clipboard.setData(ClipboardData(text: text));
    viewModel.exitSelectionMode();
    if (context.mounted) {
      _showMessage(context, '已复制 $selectedCount 条记录');
    }
  }

  Future<void> _delete(BuildContext context) async {
    final count = viewModel.selectedItemIds.length;
    // 1.2.5：批量删除同样二次确认（与单条删除统一图标与文案）。
    final confirmed = await showPineVaultDeleteConfirmDialog(
      context,
      title: '请确认是否删除这 $count 条密码？',
      message: '删除后这 $count 条密码会移入回收站，可在「设置 → 回收站」中找回，30 天后自动清理。',
    );
    if (confirmed != true || !context.mounted) return;
    final ok = await viewModel.batchDelete();
    if (context.mounted && ok) _showMessage(context, '已移入回收站 $count 条记录');
  }
}
/// 密码库页顶部三个等分按钮：外观与搜索框一致（白底、圆角 16、浅色描边）。
class _VaultHeaderButton extends StatelessWidget {
  const _VaultHeaderButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  final IconData icon;
  final String label;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SizedBox(
      height: 48,
      child: OutlinedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 20),
        label: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
        style: OutlinedButton.styleFrom(
          backgroundColor: theme.colorScheme.surfaceContainerLow,
          foregroundColor: theme.colorScheme.primary,
          disabledForegroundColor: theme.colorScheme.onSurfaceVariant,
          padding: const EdgeInsets.symmetric(horizontal: 6),
          textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
          side: BorderSide(color: theme.colorScheme.outlineVariant),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(16)),
          ),
        ),
      ),
    );
  }
}
