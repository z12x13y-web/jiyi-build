import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../data/services/app_preferences_service.dart';

/// 内置默认背景：用户没有设置自定义背景时，用这张打包在 APK 里的图片。
/// 旧版本在无背景时是纯色底，现改为默认图片。
const String kDefaultBackgroundAsset =
    'assets/backgrounds/default_background.jpg';

/// 全屏背景层：默认显示内置背景图；设置了自定义背景后替换为用户的图片。
/// 遮罩已移除，仅保留「自定义模糊」。
class PineVaultBackgroundLayer extends StatelessWidget {
  const PineVaultBackgroundLayer({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppPreferences.instance,
      builder: (context, _) {
        final prefs = AppPreferences.instance;
        final path = prefs.backgroundPath;
        final blur = prefs.backgroundBlur;
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            // 兜底底色：只在图片加载失败时可见，正常不可见。
            const ColoredBox(color: Color(0xFF0E1A2B)),
            // RepaintBoundary：切页或局部重建时复用已绘制的背景，避免闪一下底色。
            RepaintBoundary(
              child: blur > 0
                  ? ImageFiltered(
                      imageFilter: ui.ImageFilter.blur(
                        sigmaX: blur,
                        sigmaY: blur,
                      ),
                      child: _BackgroundImage(path: path),
                    )
                  : _BackgroundImage(path: path),
            ),
            child,
          ],
        );
      },
    );
  }
}

class _BackgroundImage extends StatelessWidget {
  const _BackgroundImage({this.path});

  /// 自定义背景路径；为空时使用内置默认背景。
  final String? path;

  /// 同一路径复用同一个 provider，配合 gaplessPlayback 避免重建时闪白。
  static final Map<String, FileImage> _providers = <String, FileImage>{};

  @override
  Widget build(BuildContext context) {
    final asset = Image.asset(
      kDefaultBackgroundAsset,
      fit: BoxFit.cover,
      filterQuality: FilterQuality.low,
    );
    final customPath = path;
    if (customPath == null || customPath.isEmpty) return asset;
    return Image(
      image: _providers.putIfAbsent(customPath, () => FileImage(File(customPath))),
      fit: BoxFit.cover,
      filterQuality: FilterQuality.low,
      gaplessPlayback: true,
      errorBuilder: (context, error, stackTrace) => asset,
    );
  }
}
