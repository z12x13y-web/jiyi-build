import 'dart:io';

import 'dart:math' as math;
import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../data/services/app_preferences_service.dart';
import '../../../data/services/native_autofill_service.dart';
import '../../../data/services/totp_service.dart';
import '../../../domain/models/totp_config.dart';
import '../../../domain/models/vault_item.dart';
import '../../../domain/models/vault_group.dart';
import '../../core/vault_brand.dart';
import '../../core/app_feedback.dart';
import '../../core/app_theme.dart';
import '../../core/pine_vault_page_route.dart';
import '../../core/pine_vault_widgets.dart';
import '../settings/change_master_password_dialog.dart';
import '../settings/device_unlock_sheet.dart';
import '../settings/sync_history_screen.dart';
import '../settings/storage_paths_screen.dart';
import '../settings/webdav_settings_screen.dart';
import '../backup/backup_screen.dart';
import '../backup/backup_view_model.dart';
import 'vault_bottom_bar.dart';
import 'vault_view_model.dart';

part 'vault_home_kdbx.dart';
part 'vault_home_list.dart';
part 'vault_home_groups.dart';
part 'vault_home_item_actions.dart';
part 'vault_home_item_viewer.dart';
part 'vault_home_item_editor.dart';

class VaultHomeScreen extends StatefulWidget {
  const VaultHomeScreen({super.key});

  @override
  State<VaultHomeScreen> createState() => _VaultHomeScreenState();
}

class _VaultHomeScreenState extends State<VaultHomeScreen>
    with WidgetsBindingObserver {
  static const _wideLayoutMinWidth = 900.0;

  bool _automaticBackupChecked = false;
  bool _automaticBackupCheckScheduled = false;
  String? _activeItemId;
  bool _pendingSaveRefreshCheck = true;

  int _tabIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _pendingSaveRefreshCheck = true;
      _schedulePendingSaveRefresh(context.read<VaultViewModel>());
    }
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = context.watch<VaultViewModel>();
    _schedulePendingSaveRefresh(viewModel);
    // 1.2.2：宽屏与否已不影响 AppBar，局部变量不再需要。
    _scheduleAutomaticBackupCheck(viewModel);
    // 1.2.7：底栏高度随时可调，页面跟着偏好实时重建。
    return ListenableBuilder(
      listenable: AppPreferences.instance,
      builder: (context, _) {
        final AppPreferences prefs = AppPreferences.instance;
        // 1.2.7：底栏开关。关闭后回到页面顶部的「新建 / 同步 / 设置」按钮。
        final bool showBottomBar = prefs.frostedBottomBarEnabled;
        // 多选时把底部让给批量操作栏，两个栏不叠加。
        final bool showFloatingBar = showBottomBar && !viewModel.selectionMode;
        // 1.2.7：底栏浮在正文之上，三个页面的列表都要按它让出底部空间。
        final double bottomInset = showFloatingBar
            ? VaultBottomBar.reservedHeight(context)
            : 0;
        return PopScope(
          // 同步 / 设置页按返回键或侧滑时回到密码库页，而不是退出应用。
          canPop: _tabIndex == 0,
          onPopInvokedWithResult: (didPop, result) {
            if (didPop) return;
            if (_tabIndex != 0) setState(() => _tabIndex = 0);
          },
          child: Scaffold(
            // 让列表一直滚到玻璃下面：底栏不是「切掉一块」，
            // 而是真的浮在密码列表 / 电影海报这类内容之上。
            extendBody: showFloatingBar,
            appBar: _buildHomeAppBar(viewModel),
            // 1.2.7：磨砂玻璃悬浮底栏。密码库 / 同步 / 设置与「+ 新建」都收在这里。
            bottomNavigationBar: showFloatingBar
                ? VaultBottomBar(
                    selectedIndex: _tabIndex,
                    onSelect: (index) {
                      FocusManager.instance.primaryFocus?.unfocus();
                      setState(() => _tabIndex = index);
                    },
                    onAdd: () {
                      FocusManager.instance.primaryFocus?.unfocus();
                      _openEditor(context, viewModel);
                    },
                    addEnabled: !viewModel.busy,
                  )
                : null,
            body: Stack(
              children: [
                Column(
                  children: [
                    if (viewModel.syncProgress case final progress?) ...[
                      const LinearProgressIndicator(),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 6,
                        ),
                        child: Text(progress),
                      ),
                    ],
                    if (viewModel.webDavConflict)
                      MaterialBanner(
                        content: const Text(
                          '检测到其他设备使用了不同的 WebDAV 配置，本次同步已保留当前设备配置。',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.push<void>(
                              context,
                              PineVaultPageRoute(
                                builder: (_) => const WebDavSettingsScreen(),
                              ),
                            ),
                            child: const Text('检查配置'),
                          ),
                        ],
                      ),
                    Expanded(
                      child: IndexedStack(
                        index: _tabIndex,
                        // 1.2.2：只有三个页面。原来第 2 项是"新建"页，
                        // 它既不是页面、又堆满了同步与设置的功能，已整体删除。
                        children: [
                          RepaintBoundary(
                            child: _buildVaultTab(
                              viewModel,
                              showHeaderActions: !showBottomBar,
                              bottomInset: bottomInset,
                            ),
                          ),
                          RepaintBoundary(
                            child: _buildSyncTab(
                              viewModel,
                              bottomInset: bottomInset,
                            ),
                          ),
                          RepaintBoundary(
                            child: _buildSettingsTab(
                              viewModel,
                              bottomInset: bottomInset,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // 1.2.2：不再需要 isWideLayout —— 宽屏专属的"新建"按钮已移除。
  // 1.2.7：新建入口固定在底栏右侧的「+」，关掉底栏时回退到顶部按钮。
  PreferredSizeWidget _buildHomeAppBar(VaultViewModel viewModel) {
    final Widget title = switch (_tabIndex) {
      0 => const VaultBrand(compact: true, showIcon: false),
      1 => const Text('同步'),
      _ => const Text('设置'),
    };
    return AppBar(
      backgroundColor: Colors.transparent,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
      leading: _tabIndex == 0
          ? null
          : IconButton(
              tooltip: '返回密码库',
              icon: const Icon(Icons.arrow_back_rounded),
              onPressed: () => setState(() => _tabIndex = 0),
            ),
      title: title,
      actions: [
        if (viewModel.busy)
          const Padding(
            padding: EdgeInsets.all(16),
            child: SizedBox.square(
              dimension: 20,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ),
        // 1.2.7：原三条杠菜单已删除；展示密码 / 多选直接放在标题右侧。
        if (_tabIndex == 0) ...[
          IconButton(
            key: const Key('toggle-passwords'),
            tooltip: viewModel.showPasswords ? '隐藏密码' : '展示密码',
            onPressed: () =>
                viewModel.setShowPasswords(!viewModel.showPasswords),
            icon: Icon(
              viewModel.showPasswords
                  ? Icons.visibility_off_outlined
                  : Icons.visibility_outlined,
            ),
          ),
          IconButton(
            key: const Key('start-multi-select'),
            tooltip: '多选操作',
            onPressed: viewModel.startSelectionMode,
            icon: const Icon(Icons.checklist_rounded),
          ),
        ],
      ],
    );
  }

  Widget _buildVaultTab(
    VaultViewModel viewModel, {
    required bool showHeaderActions,
    required double bottomInset,
  }) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth >= _wideLayoutMinWidth) {
          VaultItem? activeItem;
          for (final item in viewModel.items) {
            if (item.id == _activeItemId) {
              activeItem = item;
              break;
            }
          }
          final listWidth = (constraints.maxWidth * 0.42).clamp(400.0, 480.0);
          return Row(
            children: [
              SizedBox(
                width: listWidth,
                child: _VaultList(
                  viewModel: viewModel,
                  showHeaderActions: showHeaderActions,
                  bottomInset: bottomInset,
                  selectedItemId: activeItem?.id,
                  onOpenSync: () => setState(() => _tabIndex = 1),
                  onOpenSettings: () => setState(() => _tabIndex = 2),
                  onItemTap: (item) {
                    setState(() => _activeItemId = item.id);
                  },
                ),
              ),
              const VerticalDivider(width: 1),
              Expanded(
                child: activeItem == null
                    ? Center(
                        child: Text(
                          '选择一个条目，或创建新密码',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      )
                    : _ItemViewer(
                        key: ValueKey(activeItem.id),
                        viewModel: viewModel,
                        item: activeItem,
                        onClose: () {
                          setState(() => _activeItemId = null);
                        },
                        onEdit: () =>
                            _openEditor(context, viewModel, activeItem),
                        onDeleted: () {
                          setState(() => _activeItemId = null);
                        },
                      ),
              ),
            ],
          );
        }
        return _VaultList(
          viewModel: viewModel,
          showHeaderActions: showHeaderActions,
          bottomInset: bottomInset,
          onOpenSync: () => setState(() => _tabIndex = 1),
          onOpenSettings: () => setState(() => _tabIndex = 2),
        );
      },
    );
  }

  Widget _navigationTile({
    IconData? icon,
    Widget? leading,
    required String title,
    String? subtitle,
    required VoidCallback? onTap,
    Color? iconColor,
  }) {
    return PineVaultSurface(
      margin: const EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.zero,
      radius: PineVaultRadii.md,
      onTap: onTap,
      child: PineVaultListTile(
        icon: icon,
        leading: leading,
        title: title,
        subtitle: subtitle,
        iconColor: iconColor,
        showChevron: true,
      ),
    );
  }

  Widget _switchTile({
    required IconData icon,
    required String title,
    String? subtitle,
    required bool value,
    required ValueChanged<bool>? onChanged,
  }) {
    return PineVaultSurface(
      margin: const EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.zero,
      radius: PineVaultRadii.md,
      child: PineVaultListTile(
        icon: icon,
        title: title,
        subtitle: subtitle,
        trailing: Switch.adaptive(value: value, onChanged: onChanged),
      ),
    );
  }

  Future<void> _pushScreen(Widget screen) {
    return Navigator.push<void>(
      context,
      PineVaultPageRoute<void>(builder: (_) => screen),
    );
  }

  Widget _buildSyncTab(
    VaultViewModel viewModel, {
    required double bottomInset,
  }) {
    final theme = Theme.of(context);
    final progress = viewModel.syncProgress;
    final message = viewModel.syncMessage;
    return ListView(
      // 1.2.7：底栏浮在内容之上，列表按底栏实际高度多留一段，
      // 最后一项才能滚到玻璃上方。
      padding: EdgeInsets.fromLTRB(16, 4, 16, 24.0 + bottomInset),
      children: [
        PineVaultSurface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const PineVaultIconBadge(
                    icon: Icons.cloud_sync_rounded,
                    size: 46,
                    radius: 15,
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('WebDAV 云同步', style: theme.textTheme.titleMedium),
                        const SizedBox(height: 2),
                        Text(
                          viewModel.busy ? '同步进行中…' : '保持多设备密码一致',
                          style: theme.textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: viewModel.busy
                      ? null
                      : () => _sync(context, viewModel),
                  icon: const Icon(Icons.sync_rounded),
                  label: const Text('立即同步'),
                ),
              ),
              const SizedBox(height: 14),
              // 1.2.5：自动同步周期（1 / 3 / 7 天，默认 3 天）。
              const _AutoSyncIntervalPicker(),
              if (progress != null) ...[
                const SizedBox(height: 12),
                const LinearProgressIndicator(),
                const SizedBox(height: 6),
                Text(progress, style: theme.textTheme.bodySmall),
              ],
              if (message != null) ...[
                const SizedBox(height: 8),
                Text(message, style: theme.textTheme.bodySmall),
              ],
            ],
          ),
        ),
        const PineVaultSectionLabel('同步配置'),
        _navigationTile(
          icon: Icons.cloud_outlined,
          title: 'WebDAV 设置',
          subtitle: '服务器地址、账号与密码',
          onTap: () => _pushScreen(const WebDavSettingsScreen()),
        ),
        // 1.2.7：备份与恢复从设置页移到同步页，放在同步历史上面。
        _navigationTile(
          icon: Icons.settings_backup_restore_rounded,
          title: '备份与恢复',
          subtitle: '本地备份管理与恢复',
          onTap: () => _pushScreen(const BackupScreen()),
        ),
        _navigationTile(
          icon: Icons.history_rounded,
          title: '同步历史',
          subtitle: '查看最近同步记录',
          onTap: () => _pushScreen(const SyncHistoryScreen()),
        ),
        // 1.2.2：「备份与恢复 / 导入 KDBX / 导出 KDBX / 分组管理」不属于云同步，
        // 已统一收归「设置」页，这里不再重复出现。
      ],
    );
  }

  Widget _buildSettingsTab(
    VaultViewModel viewModel, {
    required double bottomInset,
  }) {
    return ListView(
      // 1.2.7：底栏浮在内容之上，设置页同样为它让出底部空间。
      padding: EdgeInsets.fromLTRB(16, 4, 16, 24.0 + bottomInset),
      children: [
        const PineVaultSectionLabel('安全'),
        _switchTile(
          icon: Icons.fingerprint_rounded,
          title: '生物识别解锁',
          subtitle: viewModel.deviceUnlockSupported
              ? (viewModel.deviceUnlockEnabled ? '已开启' : '未开启')
              : '当前设备不支持',
          value: viewModel.deviceUnlockEnabled,
          onChanged:
              (viewModel.deviceUnlockSupported && !viewModel.deviceUnlockBusy)
              ? (value) => _handleMenu(context, _VaultMenuAction.deviceUnlock)
              : null,
        ),
        _navigationTile(
          icon: Icons.password_rounded,
          title: '修改主密码',
          subtitle: '更新解锁保险库的主密码',
          onTap: () =>
              _handleMenu(context, _VaultMenuAction.changeMasterPassword),
        ),
        _navigationTile(
          icon: Icons.lock_clock_rounded,
          title: '自动锁定',
          subtitle: _autoLockLabel(),
          onTap: () => _editAutoLock(context),
        ),
        const PineVaultSectionLabel('界面'),
        // 1.2.7：底栏开关。关掉后密码库页顶部会重新出现三个按钮，
        // 不会出现「关掉底栏后无处可去」的情况。
        _switchTile(
          icon: Icons.layers_rounded,
          title: '磨砂玻璃底栏',
          subtitle: AppPreferences.instance.frostedBottomBarEnabled
              ? '已开启：底栏三加一显示（密码 / 同步 / 设置 + 新建）'
              : '已关闭：使用密码库页顶部的新建 / 同步 / 设置按钮',
          value: AppPreferences.instance.frostedBottomBarEnabled,
          onChanged: (value) async {
            await AppPreferences.instance.setFrostedBottomBarEnabled(value);
            if (mounted) setState(() {});
          },
        ),
        // 1.2.7：自定义背景与移除背景合并为一项。
        _navigationTile(
          icon: Icons.wallpaper_rounded,
          title: '自定义背景',
          subtitle: AppPreferences.instance.hasCustomBackground
              ? '已设置，点击更换或恢复默认'
              : '未设置，点击选择图片',
          onTap: () => _editBackground(context),
        ),
        _navigationTile(
          icon: Icons.blur_on_rounded,
          title: '自定义模糊',
          subtitle:
              '当前 ${AppPreferences.instance.backgroundBlur.toStringAsFixed(0)}',
          onTap: () => _editBackgroundBlur(context),
        ),
        const PineVaultSectionLabel('关于'),
        PineVaultSurface(
          margin: const EdgeInsets.only(bottom: 10),
          padding: EdgeInsets.zero,
          radius: PineVaultRadii.md,
          // 只保留图标与版本号：不含软件名、不含「历史版本」入口。
          // 版本号需与 pubspec.yaml 的 version 保持一致。
          child: const PineVaultListTile(
            icon: Icons.info_outline_rounded,
            title: '版本 1.1.3',
          ),
        ),
        // 1.2.7：存储路径移到版本号下面。
        _navigationTile(
          icon: Icons.folder_open_outlined,
          title: '存储路径',
          subtitle: '查看密码库、备份与云端文件的实际位置',
          onTap: () => _pushScreen(const StoragePathsScreen()),
        ),
      ],
    );
  }

  String _autoLockLabel() {
    final int seconds = AppPreferences.instance.autoLockSeconds;
    if (seconds < 0) return '永不';
    if (seconds == 0) return '立即';
    if (seconds < 60) return '$seconds 秒';
    final int minutes = seconds ~/ 60;
    final int rest = seconds % 60;
    return rest == 0 ? '$minutes 分钟' : '$minutes 分 $rest 秒';
  }

  Future<void> _editAutoLock(BuildContext context) async {
    final AppPreferences prefs = AppPreferences.instance;
    final int current = prefs.autoLockSeconds;
    var mode = current < 0 ? 2 : (current == 0 ? 0 : 1);
    double minutes = current > 0
        ? (current / 60).clamp(1.0, 120.0).toDouble()
        : 1.0;
    final saved = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheetState) {
          final ThemeData theme = Theme.of(sheetContext);
          int valueForSave() =>
              mode == 2 ? -1 : (mode == 0 ? 0 : (minutes * 60).round());
          return SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text('自动锁定', style: theme.textTheme.titleLarge),
                  const SizedBox(height: 6),
                  _AutoLockOption(
                    selected: mode == 0,
                    title: '立即',
                    subtitle: '退到后台后马上锁定',
                    onTap: () => setSheetState(() => mode = 0),
                  ),
                  _AutoLockOption(
                    selected: mode == 1,
                    title: '自定义时间',
                    subtitle: '${minutes.round()} 分钟后锁定',
                    onTap: () => setSheetState(() => mode = 1),
                  ),
                  if (mode == 1)
                    Slider(
                      value: minutes,
                      min: 1,
                      max: 120,
                      divisions: 119,
                      label: '${minutes.round()} 分钟',
                      onChanged: (value) =>
                          setSheetState(() => minutes = value),
                    ),
                  _AutoLockOption(
                    selected: mode == 2,
                    title: '永不',
                    subtitle: '不自动锁定，下次打开仍保持已解锁',
                    onTap: () => setSheetState(() => mode = 2),
                  ),
                  const SizedBox(height: 10),
                  FilledButton(
                    onPressed: () =>
                        Navigator.pop(sheetContext, valueForSave()),
                    child: const Text('保存'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
    if (saved == null) return;
    await AppPreferences.instance.setAutoLockSeconds(saved);
    if (mounted) setState(() {});
  }

  Future<void> _editBackground(BuildContext context) async {
    final bool hasCustom = AppPreferences.instance.hasCustomBackground;
    final String? action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: const Icon(Icons.image_outlined),
              title: const Text('选择图片'),
              subtitle: const Text('从相册选择新的背景'),
              onTap: () => Navigator.pop(sheetContext, 'pick'),
            ),
            if (hasCustom)
              ListTile(
                leading: const Icon(Icons.hide_image_outlined),
                title: const Text('恢复默认背景'),
                subtitle: const Text('移除当前自定义背景'),
                onTap: () => Navigator.pop(sheetContext, 'remove'),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (!context.mounted || action == null) return;
    if (action == 'pick') await _pickBackground(context);
    if (action == 'remove') await _removeBackground(context);
  }

  /// 设置页「自定义模糊」：用底部弹窗的滑块调整背景模糊半径。
  Future<void> _editBackgroundBlur(BuildContext context) async {
    var value = AppPreferences.instance.backgroundBlur.clamp(0.0, 30.0);
    final result = await showModalBottomSheet<double>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('自定义模糊', style: Theme.of(sheetContext).textTheme.titleLarge),
              const SizedBox(height: 4),
              Text(
                '模糊半径 ${value.toStringAsFixed(0)}（0 为不模糊）',
                style: Theme.of(sheetContext).textTheme.bodyMedium,
              ),
              Slider(
                value: value,
                min: 0,
                max: 30,
                divisions: 30,
                label: value.toStringAsFixed(0),
                onChanged: (next) => setSheetState(() => value = next),
              ),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: () => Navigator.pop(sheetContext, value),
                child: const Text('保存'),
              ),
            ],
          ),
        ),
      ),
    );
    if (result == null) return;
    await AppPreferences.instance.setBackgroundBlur(result);
    if (mounted) setState(() {});
  }

  /// 设置页「自定义背景」：选一张图片复制进应用私有目录并立即生效。
  Future<void> _pickBackground(BuildContext context) async {
    try {
      final file = await FilePicker.pickFile(
        dialogTitle: '选择背景图片',
        type: FileType.image,
      );
      if (file == null) return;
      final path = file.path;
      if (path == null) return;
      // 立刻校验能否解码：不行就提示，而不是静默回落到默认背景。
      final savedPath = await AppPreferences.instance.saveBackgroundImage(path);
      try {
        await precacheImage(FileImage(File(savedPath)), context);
      } catch (_) {
        if (mounted) {
          showAppMessage(context, '这张图片无法作为背景，请换一张');
        }
      }
      if (mounted) setState(() {});
    } catch (error) {
      if (mounted) showAppMessage(context, '设置背景失败：$error');
    }
  }

  /// 移除自定义背景，恢复默认纯色底。
  Future<void> _removeBackground(BuildContext context) async {
    await AppPreferences.instance.resetBackground();
    if (mounted) setState(() {});
  }

  void _schedulePendingSaveRefresh(VaultViewModel viewModel) {
    if (!_pendingSaveRefreshCheck ||
        viewModel.state != VaultAppState.unlocked) {
      return;
    }
    _pendingSaveRefreshCheck = false;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted || !await NativeAutofillService.hasPendingSaveRefresh()) {
        return;
      }
      final refreshed = await viewModel.reloadAfterAutofillSave();
      if (refreshed) {
        await NativeAutofillService.clearPendingSaveRefresh();
      }
    });
  }

  void _scheduleAutomaticBackupCheck(VaultViewModel viewModel) {
    if (_automaticBackupChecked ||
        _automaticBackupCheckScheduled ||
        viewModel.state != VaultAppState.unlocked) {
      return;
    }
    _automaticBackupCheckScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final backupViewModel = context.read<BackupViewModel>();
      final checked = await backupViewModel.checkAutomatic();
      if (!mounted) return;
      setState(() {
        _automaticBackupCheckScheduled = false;
        _automaticBackupChecked = checked;
      });
      final message = backupViewModel.message;
      if (checked && message != null) {
        showAppMessage(context, message);
      }
    });
  }
}

enum _VaultMenuAction {
  sync,
  webDav,
  history,
  backup,
  groupManagement,
  changeMasterPassword,
  deviceUnlock,
  autofill,
  multiSelect,
  lock,
  togglePasswords,
  toggleWebsites,
  toggleTotp,
  sortByTime,
  sortByName,
}

class _AutoLockOption extends StatelessWidget {
  const _AutoLockOption({
    required this.selected,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final bool selected;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(
        selected ? Icons.radio_button_checked : Icons.radio_button_off,
        color: selected ? scheme.primary : scheme.onSurfaceVariant,
      ),
      title: Text(title),
      subtitle: Text(subtitle),
      onTap: onTap,
    );
  }
}

class _VaultCountBadge extends StatelessWidget {
  const _VaultCountBadge({required this.count});

  final int count;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: '密码数量 $count',
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.black, width: 1.5),
        ),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            '$count',
            style: const TextStyle(
              color: Colors.black,
              fontSize: 18,
              fontWeight: FontWeight.w800,
              height: 1,
            ),
          ),
        ),
      ),
    );
  }
}

Future<void> _handleMenu(BuildContext context, _VaultMenuAction action) async {
  final viewModel = context.read<VaultViewModel>();
  switch (action) {
    case _VaultMenuAction.sync:
      await _sync(context, viewModel);
    case _VaultMenuAction.webDav:
      await Navigator.push<void>(
        context,
        PineVaultPageRoute(builder: (_) => const WebDavSettingsScreen()),
      );
    case _VaultMenuAction.history:
      await Navigator.push<void>(
        context,
        PineVaultPageRoute(builder: (_) => const SyncHistoryScreen()),
      );
    case _VaultMenuAction.backup:
      await Navigator.push<void>(
        context,
        PineVaultPageRoute(builder: (_) => const BackupScreen()),
      );
    case _VaultMenuAction.groupManagement:
      await _showGroupManagement(context, viewModel);
    case _VaultMenuAction.changeMasterPassword:
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.transparent,
        builder: (_) => const ChangeMasterPasswordDialog(),
      );
    case _VaultMenuAction.deviceUnlock:
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.transparent,
        builder: (_) =>
            DeviceUnlockSheet(disable: viewModel.deviceUnlockEnabled),
      );
    case _VaultMenuAction.autofill:
      break;
    case _VaultMenuAction.multiSelect:
      viewModel.startSelectionMode();
    case _VaultMenuAction.lock:
      viewModel.lock();
    case _VaultMenuAction.togglePasswords:
      viewModel.setShowPasswords(!viewModel.showPasswords);
    case _VaultMenuAction.toggleWebsites:
      viewModel.setShowWebsites(!viewModel.showWebsites);
    case _VaultMenuAction.toggleTotp:
      viewModel.setShowTotp(!viewModel.showTotp);
    case _VaultMenuAction.sortByTime:
      viewModel.setSortOrder(VaultSortOrder.time);
    case _VaultMenuAction.sortByName:
      viewModel.setSortOrder(VaultSortOrder.name);
  }
}

/// 1.2.5：「自动同步周期」选择器（1 天 / 3 天 / 7 天，默认 3 天）。
///
/// 自动同步不再由「解锁 / 重新登录 / 新增修改密码」触发，只在周期到达后执行；
/// 「立即同步」按钮不受周期限制。
class _AutoSyncIntervalPicker extends StatefulWidget {
  const _AutoSyncIntervalPicker();

  @override
  State<_AutoSyncIntervalPicker> createState() =>
      _AutoSyncIntervalPickerState();
}

class _AutoSyncIntervalPickerState extends State<_AutoSyncIntervalPicker> {
  Future<void> _select(int days) async {
    if (days == AppPreferences.instance.autoSyncIntervalDays) return;
    await AppPreferences.instance.setAutoSyncIntervalDays(days);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final int current = AppPreferences.instance.autoSyncIntervalDays;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                '自动同步周期',
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            for (final int days in AppPreferences.autoSyncIntervalOptions)
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: _option(context, days, days == current),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          '记忆只在周期到达后与云端同步（默认 3 天）；'
          '解锁、新增或修改密码时不再立即同步，需要时点「立即同步」。',
          style: theme.textTheme.bodySmall,
        ),
      ],
    );
  }

  Widget _option(BuildContext context, int days, bool selected) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: () => _select(days),
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? scheme.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: selected ? scheme.primary : scheme.outlineVariant,
          ),
        ),
        child: Text(
          '$days 天',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: selected ? scheme.onPrimary : scheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}
