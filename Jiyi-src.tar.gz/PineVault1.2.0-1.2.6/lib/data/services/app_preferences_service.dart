import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/painting.dart';
import 'package:path_provider/path_provider.dart';

/// 应用级偏好（1.2.4 新增）。
///
/// 与「保险库数据」无关的应用级设置集中在这里，持久化为应用支持目录下的
/// `app_preferences.json`：
/// 1. 自定义背景（图片路径 / 遮罩浓度 / 模糊半径）；
/// 2. 自动填充排除列表镜像、敏感页面保护；
/// 3. 界面开关（液态玻璃底栏、底栏高度、玻璃模糊 / 通透度等，见 1.2.7）。
///
/// 单例 + 内存缓存：所有 UI 通过 [instance] 读写，写入后立即落盘并
/// [notifyListeners]，界面用 ListenableBuilder 监听即可。
class AppPreferences extends ChangeNotifier {
  AppPreferences._();

  static final AppPreferences instance = AppPreferences._();

  static const String _fileName = 'app_preferences.json';

  static const String _kBackgroundPath = 'backgroundPath';
  static const String _kBackgroundBlur = 'backgroundBlur';
  static const String _kExcluded = 'excludedAutofillPackages';
  static const String _kSensitiveGuard = 'sensitivePageGuard';
  static const String _kSyncIntervalDays = 'autoSyncIntervalDays';
  static const String _kLastSyncedAt = 'lastSyncedAtMillis';
  static const String _kLiquidGlassBottomBar = 'liquidGlassBottomBar';
  static const String _kBottomBarCustomSize = 'bottomBarCustomSize';
  static const String _kBottomBarHeight = 'bottomBarHeight';
  static const String _kGlassBottomNav = 'glassBottomNav';
  static const String _kGlassBlur = 'glassBlur';
  static const String _kGlassDistortion = 'glassDistortion';
  static const String _kGlassTransparency = 'glassTransparency';
  static const String _kGlassDispersion = 'glassEdgeDispersion';

  static const double defaultBottomBarHeight = 72;
  static const double minBottomBarHeight = 56;
  static const double maxBottomBarHeight = 96;
  static const double defaultGlassBlur = 30;
  static const double defaultGlassDistortion = 15;
  static const double defaultGlassTransparency = 0.55;

  final Map<String, Object?> _data = <String, Object?>{};
  Directory? _supportDirectory;
  bool _loaded = false;

  bool get loaded => _loaded;

  /// 应用私有支持目录（首次用到时惰性创建）。
  Directory? get supportDirectory => _supportDirectory;

  /// 读取磁盘上的偏好；失败时按默认值继续（不阻塞启动）。
  Future<void> load() async {
    if (_loaded) return;
    try {
      _supportDirectory = await getApplicationSupportDirectory();
      final file = File('${_supportDirectory!.path}/$_fileName');
      if (await file.exists()) {
        final decoded = jsonDecode(await file.readAsString());
        if (decoded is Map) {
          _data.addAll(decoded.cast<String, Object?>());
        }
      }
    } catch (_) {
      // 忽略：按默认值工作。
    }
    _loaded = true;
    notifyListeners();
  }

  // ------------------------------------------------------------------ 背景

  /// 自定义背景图片路径；为空表示使用内置默认背景。
  String? get backgroundPath => _data[_kBackgroundPath] as String?;

  bool get hasCustomBackground => backgroundPath != null;

  /// 背景模糊半径（sigma）：0 表示不模糊。
  double get backgroundBlur =>
      ((_data[_kBackgroundBlur] as num?)?.toDouble() ?? 0).clamp(0.0, 30.0);

  Future<void> setBackgroundBlur(double value) async {
    _data[_kBackgroundBlur] = value.clamp(0.0, 30.0);
    notifyListeners();
    await _persist();
  }

  /// 保存用户选择的背景图：按字节复制到私有目录，文件名带时间戳，
  /// 避免同路径旧图被 Flutter 图片缓存命中而“换图不生效”。
  Future<String> saveBackgroundImage(String sourcePath) async {
    final bytes = await File(sourcePath).readAsBytes();
    if (bytes.isEmpty) {
      throw const FileSystemException('图片内容为空，请换一张图片');
    }
    final directory = await _backgroundDirectory();
    final target = File(
      '${directory.path}/bg_${DateTime.now().millisecondsSinceEpoch}'
      '${_extensionOf(sourcePath)}',
    );
    await target.writeAsBytes(bytes, flush: true);
    if (await target.length() != bytes.length) {
      throw const FileSystemException('背景图片保存不完整，请重试');
    }
    final oldPath = backgroundPath;
    if (oldPath != null) {
      PaintingBinding.instance.imageCache.evict(FileImage(File(oldPath)));
    }
    // 清掉目录里其它旧图。
    await for (final entity in directory.list()) {
      if (entity is File && entity.path != target.path) {
        try {
          await entity.delete();
        } catch (_) {
          // 忽略删除失败。
        }
      }
    }
    _data[_kBackgroundPath] = target.path;
    notifyListeners();
    await _persist();
    return target.path;
  }

  /// 恢复内置默认背景：删除自定义图片并清空记录。
  Future<void> resetBackground() async {
    final path = backgroundPath;
    if (path != null) {
      try {
        final file = File(path);
        PaintingBinding.instance.imageCache.evict(FileImage(file));
        if (await file.exists()) await file.delete();
      } catch (_) {
        // 忽略：文件已不存在。
      }
    }
    _data.remove(_kBackgroundPath);
    notifyListeners();
    await _persist();
  }

  Future<Directory> _backgroundDirectory() async {
    final support = _supportDirectory ??=
        await getApplicationSupportDirectory();
    final directory = Directory('${support.path}/background');
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }

  static String _extensionOf(String path) {
    final name = path.split(RegExp(r'[/\\]')).last;
    final dot = name.lastIndexOf('.');
    if (dot <= 0 || dot == name.length - 1) return '.jpg';
    final extension = name.substring(dot).toLowerCase();
    return extension.length > 6 ? '.jpg' : extension;
  }

  // ------------------------------------------------------------------ 界面

  /// 是否启用底部悬浮的液态玻璃底栏（默认开启）。
  ///
  /// 这是 1.2.7 新增的开关：关闭后底栏不再占位，密码库页恢复原来的
  /// 「新建 / 同步 / 设置」顶部按钮，导航入口不会丢。
  bool get liquidGlassBottomBarEnabled {
    final raw = _data[_kLiquidGlassBottomBar];
    if (raw is bool) return raw;
    return true;
  }

  Future<void> setLiquidGlassBottomBarEnabled(bool value) async {
    _data[_kLiquidGlassBottomBar] = value;
    notifyListeners();
    await _persist();
  }

  /// 是否开启「自定义底栏大小」。关闭时固定使用 72 的高度。
  bool get bottomBarCustomSize {
    final raw = _data[_kBottomBarCustomSize];
    return raw is bool ? raw : false;
  }

  /// 实际生效的底栏高度（逻辑像素）。
  double get bottomBarHeight {
    if (!bottomBarCustomSize) return defaultBottomBarHeight;
    final raw = _data[_kBottomBarHeight];
    final value = raw is num ? raw.toDouble() : defaultBottomBarHeight;
    return value.clamp(minBottomBarHeight, maxBottomBarHeight);
  }

  /// 用户在设置里选中的高度，即使当前没开启自定义也保留，方便下次打开开关。
  double get configuredBottomBarHeight {
    final raw = _data[_kBottomBarHeight];
    final value = raw is num ? raw.toDouble() : defaultBottomBarHeight;
    return value.clamp(minBottomBarHeight, maxBottomBarHeight);
  }

  Future<void> setBottomBarCustomSize(bool value, {bool persist = true}) async {
    _data[_kBottomBarCustomSize] = value;
    notifyListeners();
    if (persist) await _persist();
  }

  Future<void> setBottomBarHeight(double value, {bool persist = true}) async {
    _data[_kBottomBarHeight] = value.clamp(
      minBottomBarHeight,
      maxBottomBarHeight,
    );
    notifyListeners();
    if (persist) await _persist();
  }

  // ---------------------------------------------------------- 液态玻璃样式

  bool get glassBottomNavEnabled {
    final raw = _data[_kGlassBottomNav];
    return raw is bool ? raw : true;
  }

  double get glassBlur {
    final raw = _data[_kGlassBlur];
    final value = raw is num ? raw.toDouble() : defaultGlassBlur;
    return value.clamp(0.0, 40.0);
  }

  /// 边缘折射强度（0～40）。数值越大，玻璃边的亮边 / 内阴影越明显。
  double get glassDistortion {
    final raw = _data[_kGlassDistortion];
    final value = raw is num ? raw.toDouble() : defaultGlassDistortion;
    return value.clamp(0.0, 40.0);
  }

  /// 通透度：0 为最实，1 为最透。
  double get glassTransparency {
    final raw = _data[_kGlassTransparency];
    final value = raw is num ? raw.toDouble() : defaultGlassTransparency;
    return value.clamp(0.0, 1.0);
  }

  /// 把「通透度」换算成玻璃的白色填充不透明度。
  double get glassFillOpacity =>
      (0.84 - 0.50 * glassTransparency).clamp(0.22, 0.86).toDouble();

  bool get glassEdgeDispersion {
    final raw = _data[_kGlassDispersion];
    return raw is bool ? raw : false;
  }

  Future<void> setGlassBottomNavEnabled(
    bool value, {
    bool persist = true,
  }) async {
    _data[_kGlassBottomNav] = value;
    notifyListeners();
    if (persist) await _persist();
  }

  Future<void> setGlassBlur(double value, {bool persist = true}) async {
    _data[_kGlassBlur] = value.clamp(0.0, 40.0);
    notifyListeners();
    if (persist) await _persist();
  }

  Future<void> setGlassDistortion(double value, {bool persist = true}) async {
    _data[_kGlassDistortion] = value.clamp(0.0, 40.0);
    notifyListeners();
    if (persist) await _persist();
  }

  Future<void> setGlassTransparency(double value, {bool persist = true}) async {
    _data[_kGlassTransparency] = value.clamp(0.0, 1.0);
    notifyListeners();
    if (persist) await _persist();
  }

  Future<void> setGlassEdgeDispersion(bool value, {bool persist = true}) async {
    _data[_kGlassDispersion] = value;
    notifyListeners();
    if (persist) await _persist();
  }

  /// 恢复默认液态玻璃样式（模糊 / 扭曲 / 通透度 / 边缘色散 / 底栏玻璃开关）。
  Future<void> resetGlassStyle() async {
    _data.remove(_kGlassBottomNav);
    _data.remove(_kGlassBlur);
    _data.remove(_kGlassDistortion);
    _data.remove(_kGlassTransparency);
    _data.remove(_kGlassDispersion);
    notifyListeners();
    await _persist();
  }

  // -------------------------------------------------------------- 自动填充

  /// 排除列表：命中的包名不再展示自动填充按钮、也不提示保存。
  List<String> get excludedAutofillPackages {
    final raw = _data[_kExcluded];
    if (raw is List) {
      return raw.whereType<String>().toList(growable: false);
    }
    return const <String>[];
  }

  bool isAutofillExcluded(String packageName) =>
      excludedAutofillPackages.contains(packageName);

  Future<void> setExcludedAutofillPackages(Iterable<String> packages) async {
    final normalized =
        packages
            .where((entry) => entry.trim().isNotEmpty)
            .map((entry) => entry.trim())
            .toSet()
            .toList()
          ..sort();
    _data[_kExcluded] = normalized;
    notifyListeners();
    await _persist();
  }

  Future<void> setAutofillExcluded(String packageName, bool excluded) async {
    final current = excludedAutofillPackages.toSet();
    if (excluded) {
      current.add(packageName);
    } else {
      current.remove(packageName);
    }
    await setExcludedAutofillPackages(current);
  }

  /// 敏感页面保护：付款密码页、银行类页面一律不弹填充/保存。
  bool get sensitivePageGuard => _data[_kSensitiveGuard] as bool? ?? true;

  Future<void> setSensitivePageGuard(bool value) async {
    _data[_kSensitiveGuard] = value;
    notifyListeners();
    await _persist();
  }

  // -------------------------------------------------------------- 自动同步
  /// 自动同步周期候选（天）：用户在「同步」页三选一。
  static const List<int> autoSyncIntervalOptions = <int>[1, 3, 7];

  /// 自动同步周期（天），默认 3 天。
  int get autoSyncIntervalDays {
    final raw = _data[_kSyncIntervalDays];
    if (raw is num) {
      final days = raw.toInt();
      if (autoSyncIntervalOptions.contains(days)) return days;
    }
    return 3;
  }

  Future<void> setAutoSyncIntervalDays(int days) async {
    if (!autoSyncIntervalOptions.contains(days)) return;
    _data[_kSyncIntervalDays] = days;
    notifyListeners();
    await _persist();
  }

  /// 上一次同步成功的时间；从未同步过时为 null。
  DateTime? get lastSyncedAt {
    final raw = _data[_kLastSyncedAt];
    if (raw is num) {
      return DateTime.fromMillisecondsSinceEpoch(raw.toInt());
    }
    return null;
  }

  /// 1.2.5：距上一次同步是否已满一个周期（从未同步过视为已到期）。
  bool get autoSyncDue {
    final last = lastSyncedAt;
    if (last == null) return true;
    return DateTime.now().difference(last).inDays >= autoSyncIntervalDays;
  }

  /// 记录一次同步成功（作为周期计时起点）。
  Future<void> markSyncedAt(DateTime time) async {
    _data[_kLastSyncedAt] = time.millisecondsSinceEpoch;
    notifyListeners();
    await _persist();
  }

  // ------------------------------------------------------------------ 落盘

  Future<void> _persist() async {
    try {
      final support = _supportDirectory ??=
          await getApplicationSupportDirectory();
      final file = File('${support.path}/$_fileName');
      if (!await support.exists()) {
        await support.create(recursive: true);
      }
      await file.writeAsString(jsonEncode(_data), flush: true);
    } catch (_) {
      // 写入失败不影响本次会话内的设置生效。
    }
  }
}
