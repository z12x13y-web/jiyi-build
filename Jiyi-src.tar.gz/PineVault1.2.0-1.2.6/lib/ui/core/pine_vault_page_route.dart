import 'package:flutter/material.dart';

import 'pine_vault_background_layer.dart';

/// 带不透明背景的页面路由。
///
/// 页面自身铺一层背景图，因此转场时旧页面会被完全盖住，
/// 不会出现「两个页面叠加」的观感；转场用 160ms 淡入，几乎无感。
class PineVaultPageRoute<T> extends MaterialPageRoute<T> {
  PineVaultPageRoute({
    required super.builder,
    super.settings,
    super.fullscreenDialog,
  });

  @override
  Duration get transitionDuration => const Duration(milliseconds: 160);

  @override
  Duration get reverseTransitionDuration => const Duration(milliseconds: 120);

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    return PineVaultPageBackground(
      child: super.buildPage(context, animation, secondaryAnimation),
    );
  }
}
