import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../data/services/app_preferences_service.dart';
import 'background_image_cache.dart';

export 'background_image_cache.dart' show kDefaultBackgroundAsset;

/// 全屏背景层：默认显示内置背景图；设置了自定义背景后替换为用户的图片。
///
/// 内置图在 `runApp` 之前就已解码成 [ui.Image]（见 [BackgroundImageCache]），
/// 这里用 [RawImage] 同步绘制，保证 Flutter 的第一帧就带背景，不会先闪一层底色。
class PineVaultBackgroundLayer extends StatelessWidget {
  const PineVaultBackgroundLayer({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppPreferences.instance,
      builder: (context, _) {
        final prefs = AppPreferences.instance;
        final path = prefs.backgroundPath;
        final blur = prefs.backgroundBlur;
        return Stack(
          fit: StackFit.expand,
          children: <Widget>[
            // 兜底底色：与内置背景同色系，图片未就绪时也不会露出白色。
            const ColoredBox(color: Color(0xFF0E1A2B)),
            RepaintBoundary(
              child: blur > 0
                  ? ImageFiltered(
                      imageFilter: ui.ImageFilter.blur(
                        sigmaX: blur,
                        sigmaY: blur,
                      ),
                      child: _BackgroundImage(path: path),
                    )
                  : _BackgroundImage(path: path),
            ),
            child,
          ],
        );
      },
    );
  }
}

class _BackgroundImage extends StatelessWidget {
  const _BackgroundImage({this.path});

  /// 自定义背景路径；为空时使用内置默认背景。
  final String? path;

  /// 同一路径复用同一个 provider，配合 gaplessPlayback 避免重建时闪白。
  static final Map<String, FileImage> _providers = <String, FileImage>{};

  @override
  Widget build(BuildContext context) {
    final customPath = path;
    if (customPath == null || customPath.isEmpty) {
      final cached = BackgroundImageCache.defaultImage;
      if (cached != null) {
        return RawImage(
          image: cached,
          fit: BoxFit.cover,
          filterQuality: FilterQuality.low,
        );
      }
      return Image.asset(
        kDefaultBackgroundAsset,
        fit: BoxFit.cover,
        filterQuality: FilterQuality.low,
      );
    }
    return Image(
      image: _providers.putIfAbsent(
        customPath,
        () => FileImage(File(customPath)),
      ),
      fit: BoxFit.cover,
      filterQuality: FilterQuality.low,
      gaplessPlayback: true,
      errorBuilder: (context, error, stackTrace) => Image.asset(
        kDefaultBackgroundAsset,
        fit: BoxFit.cover,
      ),
    );
  }
}
