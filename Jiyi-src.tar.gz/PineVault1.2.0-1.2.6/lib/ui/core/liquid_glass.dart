import 'dart:ui' as ui;

import 'package:flutter/material.dart';

/// 液态玻璃容器（Liquid Glass）。
///
/// 与普通的半透明卡片不同，这里叠了四层，尽量接近 iOS 26 的「液态玻璃」：
/// 1. 真正的背景模糊（[BackdropFilter]），能透出后面的背景图 / 列表；
/// 2. 从左上到右下的白色渐变底色，让玻璃有一点厚度；
/// 3. 亮边：左上最亮、右上偏白、右下带一点主题色，模拟折射；
/// 4. 顶部柔光 + 底部内阴影，玻璃边缘不会「薄成一张纸」。
///
/// 只用于悬浮底栏这类小面积控件：每一层模糊都会带来 GPU 开销，
/// 不要整页铺满，也不要在滚动列表里逐项使用。
class LiquidGlass extends StatelessWidget {
  const LiquidGlass({
    super.key,
    required this.child,
    this.radius = 36,
    this.blur = 28,
    this.opacity = 0.58,
    this.tint,
    this.padding = EdgeInsets.zero,
    this.showShadow = true,
  });

  /// 玻璃里的内容。
  final Widget child;

  /// 圆角；胶囊形底栏传入高度的一半即可。
  final double radius;

  /// 背景模糊半径（sigma）。
  final double blur;

  /// 白色玻璃底的不透明度，0～1。太小会看不清黑色文字。
  final double opacity;

  /// 玻璃的着色；默认跟随表面色（浅色主题为白色）。
  final Color? tint;

  final EdgeInsetsGeometry padding;

  /// 是否在玻璃下方投一层淡淡的弥散阴影。
  final bool showShadow;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final base = tint ?? scheme.surface;
    final strong = (opacity + 0.18).clamp(0.0, 1.0).toDouble();
    final weak = (opacity - 0.20).clamp(0.0, 1.0).toDouble();
    final borderRadius = BorderRadius.circular(radius);

    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: borderRadius,
        boxShadow: showShadow
            ? <BoxShadow>[
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.14),
                  blurRadius: 26,
                  spreadRadius: -8,
                  offset: const Offset(0, 12),
                ),
                BoxShadow(
                  color: Colors.white.withValues(alpha: 0.16),
                  blurRadius: 10,
                  spreadRadius: -4,
                  offset: const Offset(0, -2),
                ),
              ]
            : null,
      ),
      child: ClipRRect(
        borderRadius: borderRadius,
        child: BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: Stack(
            fit: StackFit.passthrough,
            children: <Widget>[
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      stops: const <double>[0.0, 0.52, 1.0],
                      colors: <Color>[
                        Colors.white.withValues(alpha: strong),
                        base.withValues(alpha: opacity),
                        base.withValues(alpha: weak),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _LiquidGlassSheenPainter(
                      radius: radius,
                      tint: scheme.primary,
                    ),
                  ),
                ),
              ),
              Padding(padding: padding, child: child),
            ],
          ),
        ),
      ),
    );
  }
}

/// 画玻璃的亮边与内部柔光。
class _LiquidGlassSheenPainter extends CustomPainter {
  const _LiquidGlassSheenPainter({required this.radius, required this.tint});

  final double radius;
  final Color tint;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final Rect rect = Offset.zero & size;
    final RRect rrect = RRect.fromRectAndRadius(
      rect.deflate(0.8),
      Radius.circular(radius),
    );

    // 渐变亮边：左上接近纯白，右下带一点主题色，像光线穿过玻璃边缘。
    final Paint border = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        stops: const <double>[0.0, 0.34, 0.72, 1.0],
        colors: <Color>[
          Colors.white.withValues(alpha: 0.92),
          Colors.white.withValues(alpha: 0.34),
          tint.withValues(alpha: 0.30),
          Colors.white.withValues(alpha: 0.58),
        ],
      ).createShader(rect);
    canvas.drawRRect(rrect, border);

    canvas.save();
    canvas.clipRRect(rrect);

    // 左上角的柔光：让玻璃有「凸起来」的厚度。
    final Rect sheenRect = Rect.fromLTWH(
      -size.width * 0.15,
      -size.height * 0.35,
      size.width * 0.95,
      size.height * 0.95,
    );
    final Paint sheen = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.2, -0.55),
        radius: 0.95,
        colors: <Color>[
          Colors.white.withValues(alpha: 0.34),
          Colors.white.withValues(alpha: 0.0),
        ],
      ).createShader(sheenRect);
    canvas.drawRect(sheenRect, sheen);

    // 底部内阴影：不给黑色描边也能看清底边。
    final Rect shadeRect = Rect.fromLTWH(
      0,
      size.height * 0.66,
      size.width,
      size.height * 0.34,
    );
    final Paint shade = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: <Color>[
          Colors.black.withValues(alpha: 0.0),
          Colors.black.withValues(alpha: 0.07),
        ],
      ).createShader(shadeRect);
    canvas.drawRect(shadeRect, shade);

    canvas.restore();
  }

  @override
  bool shouldRepaint(_LiquidGlassSheenPainter oldDelegate) {
    return oldDelegate.radius != radius || oldDelegate.tint != tint;
  }
}
