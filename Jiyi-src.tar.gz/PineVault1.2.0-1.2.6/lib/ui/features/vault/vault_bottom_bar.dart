import 'package:flutter/material.dart';

import '../../../data/services/app_preferences_service.dart';
import '../../core/pine_vault_widgets.dart';

/// 密码库 / 同步 / 设置三页共用的悬浮底栏。
///
/// 外观与软件里的搜索框、设置卡片一致：半透明白色 + 黑色描边（[PineVaultFrosted]）。
///
/// 左边是一整块胶囊磨砂玻璃，里面三个图标 + 文字的 Tab；右边是独立的圆形
/// 「+」按钮。1.2.7 起支持在设置 → 界面里开关底栏、调整高度。
class VaultBottomBar extends StatelessWidget {
  const VaultBottomBar({
    super.key,
    required this.selectedIndex,
    required this.onSelect,
    required this.onAdd,
    this.addEnabled = true,
  });

  /// 当前选中的页面：0 密码库 / 1 同步 / 2 设置。
  final int selectedIndex;

  final ValueChanged<int> onSelect;

  /// 点右侧「+」：新建一条密码。
  final VoidCallback onAdd;

  /// 密码库正在保存 / 同步时禁用新建，避免并发写入。
  final bool addEnabled;

  static const double _defaultHeight = 72;
  static const double _topGap = 6;
  static const double _sideGap = 14;
  static const double _bottomGap = 10;

  /// 页面内容需要为悬浮底栏让出的高度（含系统手势区与一点呼吸空间）。
  ///
  /// 底栏是浮在内容之上的（Scaffold.extendBody），列表底部要留出这段距离，
  /// 否则最后一条密码会永远压在磨砂玻璃下面。
  static double reservedHeight(BuildContext context) {
    final prefs = AppPreferences.instance;
    if (!prefs.frostedBottomBarEnabled) return 0;
    final media = MediaQuery.maybeOf(context);
    final double bottomInset = media?.padding.bottom ?? 0.0;
    final safeBottom = bottomInset > _bottomGap ? bottomInset : _bottomGap;
    return prefs.bottomBarHeight + _topGap + safeBottom + 16.0;
  }

  @override
  Widget build(BuildContext context) {
    final prefs = AppPreferences.instance;
    final double height = prefs.bottomBarHeight;
    final double scale = height / _defaultHeight;

    return Material(
      type: MaterialType.transparency,
      child: SafeArea(
        top: false,
        minimum: const EdgeInsets.only(bottom: _bottomGap),
        // 固定高度：Scaffold 给底栏的是「最大高度 = 整屏」的宽松约束，
        // 这里若用没有 heightFactor 的 Align，会被撑成整屏高、把正文挤没。
        child: SizedBox(
          height: height + _topGap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(_sideGap, _topGap, _sideGap, 0),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Expanded(
                      child: PineVaultFrosted(
                        radius: height / 2,
                        opacity: 0.34,
                        child: SizedBox(
                          height: height,
                          child: Padding(
                            padding: EdgeInsets.all(5 * scale),
                            child: Row(
                              children: <Widget>[
                                _tab(
                                  index: 0,
                                  label: '密码库',
                                  icon: Icons.key_rounded,
                                  height: height,
                                  scale: scale,
                                ),
                                _tab(
                                  index: 1,
                                  label: '同步',
                                  icon: Icons.sync_rounded,
                                  height: height,
                                  scale: scale,
                                ),
                                _tab(
                                  index: 2,
                                  label: '设置',
                                  icon: Icons.settings_rounded,
                                  height: height,
                                  scale: scale,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 10 * scale),
                    _buildAddButton(height: height, scale: scale),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _tab({
    required int index,
    required String label,
    required IconData icon,
    required double height,
    required double scale,
  }) {
    final bool selected = selectedIndex == index;
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        label: label,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          margin: EdgeInsets.symmetric(horizontal: 2 * scale),
          decoration: BoxDecoration(
            color: selected ? Colors.white.withValues(alpha: 0.42) : null,
            borderRadius: BorderRadius.circular(height),
            border: Border.all(
              color: selected
                  ? Colors.black.withValues(alpha: 0.10)
                  : Colors.transparent,
              width: 1,
            ),
          ),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              borderRadius: BorderRadius.circular(height),
              onTap: () => onSelect(index),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(
                    icon,
                    size: 21 * scale,
                    color: Colors.black.withValues(
                      alpha: selected ? 0.90 : 0.72,
                    ),
                  ),
                  SizedBox(height: 3 * scale),
                  Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12.5 * scale,
                      height: 1.05,
                      fontWeight: FontWeight.w700,
                      color: Colors.black.withValues(
                        alpha: selected ? 1.0 : 0.78,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAddButton({required double height, required double scale}) {
    return Tooltip(
      message: '新建密码',
      child: SizedBox.square(
        dimension: height,
        child: PineVaultFrosted(
          radius: height / 2,
          opacity: 0.34,
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              key: const Key('add-item'),
              customBorder: const CircleBorder(),
              onTap: addEnabled ? onAdd : null,
              child: Center(
                child: Opacity(
                  opacity: addEnabled ? 1 : 0.38,
                  child: Icon(
                    Icons.add_rounded,
                    size: 32 * scale,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
