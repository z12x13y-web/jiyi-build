import 'package:flutter/material.dart';

import '../../core/liquid_glass.dart';

/// 密码库 / 同步 / 设置三页共用的悬浮底栏。
///
/// 视觉来自设计稿：左边是一整块胶囊玻璃，里面三个图标 + 文字的 Tab；
/// 右边是独立的圆形玻璃「+」按钮。选中项用一层更亮的白色胶囊标出。
///
/// 底栏只负责展示与回调，真实的页面切换、新建逻辑仍在 [VaultHomeScreen]，
/// 这样设置页的开关可以随时把它关掉、回退到页面顶部的按钮。
class VaultBottomBar extends StatelessWidget {
  const VaultBottomBar({
    super.key,
    required this.selectedIndex,
    required this.onSelect,
    required this.onAdd,
    this.addEnabled = true,
  });

  /// 当前选中的页面：0 密码库 / 1 同步 / 2 设置。
  final int selectedIndex;

  final ValueChanged<int> onSelect;

  /// 点右侧「+」：新建一条密码。
  final VoidCallback onAdd;

  /// 密码库正在保存 / 同步时禁用新建，避免并发写入。
  final bool addEnabled;

  static const double _barHeight = 72;
  static const double _addSize = 72;

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: SafeArea(
        top: false,
        minimum: const EdgeInsets.only(bottom: 10),
        // 固定高度：Scaffold 给底栏的是「最大高度 = 整屏」的宽松约束，
        // 这里若用没有 heightFactor 的 Align，会被撑成整屏高、把正文挤没。
        child: SizedBox(
          height: _barHeight + 6,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Expanded(
                      child: LiquidGlass(
                        radius: _barHeight / 2,
                        opacity: 0.56,
                        blur: 30,
                        child: SizedBox(
                          height: _barHeight,
                          child: Padding(
                            padding: const EdgeInsets.all(5),
                            child: Row(
                              children: <Widget>[
                                _tab(
                                  index: 0,
                                  label: '密码库',
                                  icon: Icons.key_rounded,
                                  colorfulIcon: true,
                                ),
                                _tab(
                                  index: 1,
                                  label: '同步',
                                  icon: Icons.sync_rounded,
                                ),
                                _tab(
                                  index: 2,
                                  label: '设置',
                                  icon: Icons.settings_rounded,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    _buildAddButton(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _tab({
    required int index,
    required String label,
    required IconData icon,
    bool colorfulIcon = false,
  }) {
    final bool selected = selectedIndex == index;
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        label: label,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(_barHeight),
            gradient: selected
                ? LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: <Color>[
                      Colors.white.withValues(alpha: 0.78),
                      Colors.white.withValues(alpha: 0.42),
                    ],
                  )
                : null,
            border: Border.all(
              color: selected
                  ? Colors.white.withValues(alpha: 0.85)
                  : Colors.transparent,
              width: 1,
            ),
            boxShadow: selected
                ? <BoxShadow>[
                    BoxShadow(
                      color: Colors.white.withValues(alpha: 0.30),
                      blurRadius: 14,
                      spreadRadius: -2,
                    ),
                  ]
                : null,
          ),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              borderRadius: BorderRadius.circular(_barHeight),
              onTap: () => onSelect(index),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  if (colorfulIcon)
                    _passwordGlyph()
                  else
                    Icon(
                      icon,
                      size: 21,
                      color: Colors.black.withValues(
                        alpha: selected ? 0.90 : 0.72,
                      ),
                    ),
                  const SizedBox(height: 3),
                  Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12.5,
                      height: 1.05,
                      fontWeight: FontWeight.w700,
                      color: Colors.black.withValues(
                        alpha: selected ? 1.0 : 0.78,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// 设计稿里「密码」用了一枚彩色应用图标；
  /// 这里换成记忆自己的钥匙徽章（薄荷渐变），不直接搬用别人的品牌图标。
  Widget _passwordGlyph() {
    return Container(
      width: 25,
      height: 25,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0xFF6FD3AD), Color(0xFF2C8360)],
        ),
        border: Border.all(color: Colors.white.withValues(alpha: 0.55)),
        boxShadow: const <BoxShadow>[
          BoxShadow(
            color: Color(0x332C8360),
            blurRadius: 7,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: const Icon(Icons.key_rounded, size: 15, color: Colors.white),
    );
  }

  Widget _buildAddButton() {
    return Tooltip(
      message: '新建密码',
      child: SizedBox.square(
        dimension: _addSize,
        child: LiquidGlass(
          radius: _addSize / 2,
          opacity: 0.62,
          blur: 30,
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              key: const Key('add-item'),
              customBorder: const CircleBorder(),
              onTap: addEnabled ? onAdd : null,
              child: Center(
                child: Opacity(
                  opacity: addEnabled ? 1 : 0.38,
                  child: const Icon(
                    Icons.add_rounded,
                    size: 32,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
