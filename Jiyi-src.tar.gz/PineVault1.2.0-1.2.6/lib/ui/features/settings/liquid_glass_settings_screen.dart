import 'package:flutter/material.dart';

import '../../../data/services/app_preferences_service.dart';
import '../../core/app_theme.dart';
import '../../core/liquid_glass.dart';
import '../../core/pine_vault_widgets.dart';

/// 1.2.7：液态玻璃效果的完整自定义页面（参考「应用效果」设置）。
///
/// 只控制**视觉**：模糊、边缘扭曲、通透度、边缘色散，以及底栏要不要用玻璃。
/// 底栏的显示 / 隐藏和高度在上一级「界面」里，两者互不干扰。
class LiquidGlassSettingsScreen extends StatelessWidget {
  const LiquidGlassSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        title: const Text('液态玻璃效果'),
        actions: [
          TextButton(
            onPressed: () => AppPreferences.instance.resetGlassStyle(),
            child: const Text('重置'),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: ListenableBuilder(
        listenable: AppPreferences.instance,
        builder: (context, _) => const _GlassSettingsBody(),
      ),
    );
  }
}

class _GlassSettingsBody extends StatelessWidget {
  const _GlassSettingsBody();

  @override
  Widget build(BuildContext context) {
    final AppPreferences prefs = AppPreferences.instance;
    final ThemeData theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
      children: <Widget>[
        const PineVaultSectionLabel('实时预览'),
        SizedBox(
          height: 96,
          child: LiquidGlass(
            radius: 26,
            opacity: prefs.glassFillOpacity,
            blur: prefs.glassBlur,
            distortion: prefs.glassDistortion,
            dispersion: prefs.glassEdgeDispersion,
            child: Center(
              child: Text(
                '液态玻璃底栏',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Colors.black,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          '模糊越高越通透；低性能设备建议把模糊调到 20 以下。',
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const PineVaultSectionLabel('应用效果'),
        _GlassSwitchTile(
          icon: Icons.layers_rounded,
          title: '底部导航',
          subtitle: prefs.glassBottomNavEnabled ? '底栏使用液态玻璃' : '底栏使用纯色胶囊',
          value: prefs.glassBottomNavEnabled,
          onChanged: (value) => prefs.setGlassBottomNavEnabled(value),
        ),
        _GlassSliderTile(
          icon: Icons.blur_on_rounded,
          title: '模糊效果',
          valueText: prefs.glassBlur.round().toString(),
          value: prefs.glassBlur,
          min: 0,
          max: 40,
          divisions: 40,
          onChanged: (value) => prefs.setGlassBlur(value, persist: false),
          onChangeEnd: (value) => prefs.setGlassBlur(value),
        ),
        _GlassSliderTile(
          icon: Icons.water_drop_outlined,
          title: '扭曲效果',
          valueText: prefs.glassDistortion.round().toString(),
          value: prefs.glassDistortion,
          min: 0,
          max: 40,
          divisions: 40,
          onChanged: (value) => prefs.setGlassDistortion(value, persist: false),
          onChangeEnd: (value) => prefs.setGlassDistortion(value),
        ),
        _GlassSliderTile(
          icon: Icons.opacity_rounded,
          title: '通透度',
          valueText: '${(prefs.glassTransparency * 100).round()}%',
          value: prefs.glassTransparency,
          min: 0,
          max: 1,
          divisions: 100,
          onChanged: (value) =>
              prefs.setGlassTransparency(value, persist: false),
          onChangeEnd: (value) => prefs.setGlassTransparency(value),
        ),
        _GlassSwitchTile(
          icon: Icons.color_lens_outlined,
          title: '边缘色散',
          subtitle: '在玻璃边缘显示淡淡的青 / 品红色带',
          value: prefs.glassEdgeDispersion,
          onChanged: (value) => prefs.setGlassEdgeDispersion(value),
        ),
        const SizedBox(height: 18),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => prefs.resetGlassStyle(),
            icon: const Icon(Icons.restart_alt_rounded),
            label: const Text('恢复默认效果'),
          ),
        ),
      ],
    );
  }
}

class _GlassSwitchTile extends StatelessWidget {
  const _GlassSwitchTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return PineVaultSurface(
      margin: const EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.zero,
      radius: PineVaultRadii.md,
      child: SwitchListTile.adaptive(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
        secondary: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        value: value,
        onChanged: onChanged,
      ),
    );
  }
}

class _GlassSliderTile extends StatelessWidget {
  const _GlassSliderTile({
    required this.icon,
    required this.title,
    required this.valueText,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.onChanged,
    required this.onChangeEnd,
  });

  final IconData icon;
  final String title;
  final String valueText;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final ValueChanged<double> onChanged;
  final ValueChanged<double> onChangeEnd;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return PineVaultSurface(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(14, 10, 10, 0),
      radius: PineVaultRadii.md,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(icon, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 3,
                ),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHigh,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  valueText,
                  style: theme.textTheme.labelLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions,
            label: valueText,
            onChanged: onChanged,
            onChangeEnd: onChangeEnd,
          ),
        ],
      ),
    );
  }
}
