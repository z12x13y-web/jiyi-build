part of 'vault_home_screen.dart';

/// 统一的轻提示入口（批量操作栏等复用）。
void _showMessage(BuildContext context, String message) {
  showAppMessage(context, message);
}

Future<void> _sync(BuildContext context, VaultViewModel viewModel) async {
  final succeeded = await viewModel.sync();
  if (!context.mounted) return;
  final message = succeeded ? viewModel.syncMessage : viewModel.errorMessage;
  showAppMessage(context, message ?? '同步失败，请重试');
}
