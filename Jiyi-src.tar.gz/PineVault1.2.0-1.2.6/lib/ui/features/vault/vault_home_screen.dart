import 'dart:math' as math;
import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../data/services/app_preferences_service.dart';
import '../../../data/services/installed_apps_service.dart';
import '../../../data/services/native_autofill_service.dart';
import '../../../data/services/totp_service.dart';
import '../../../domain/models/totp_config.dart';
import '../../../domain/models/vault_item.dart';
import '../../../domain/models/vault_group.dart';
import '../../core/vault_brand.dart';
import '../../core/app_feedback.dart';
import '../../core/app_theme.dart';
import '../../core/pine_vault_widgets.dart';
import '../settings/change_master_password_dialog.dart';
import '../settings/device_unlock_sheet.dart';
import '../settings/sync_history_screen.dart';
import '../settings/storage_paths_screen.dart';
import '../settings/trash_screen.dart';
import '../settings/webdav_settings_screen.dart';
import '../backup/backup_screen.dart';
import '../backup/backup_view_model.dart';
import 'vault_view_model.dart';

part 'vault_home_kdbx.dart';
part 'vault_home_list.dart';
part 'vault_home_groups.dart';
part 'vault_home_item_actions.dart';
part 'vault_home_item_viewer.dart';
part 'vault_home_item_editor.dart';

class VaultHomeScreen extends StatefulWidget {
  const VaultHomeScreen({super.key});

  @override
  State<VaultHomeScreen> createState() => _VaultHomeScreenState();
}

class _VaultHomeScreenState extends State<VaultHomeScreen>
    with WidgetsBindingObserver {
  static const _wideLayoutMinWidth = 900.0;


  bool _automaticBackupChecked = false;
  bool _automaticBackupCheckScheduled = false;
  String? _activeItemId;
  bool _autofillEnabled = false;
  bool _autofillBackgroundAllowed = false;
  bool _autofillBusy = false;
  bool _pendingSaveRefreshCheck = true;

  int _tabIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refreshAutofillStatus();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _pendingSaveRefreshCheck = true;
      _refreshAutofillStatus();
      _schedulePendingSaveRefresh(context.read<VaultViewModel>());
    }
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = context.watch<VaultViewModel>();
    _schedulePendingSaveRefresh(viewModel);
    // 1.2.2：宽屏与否已不影响 AppBar，局部变量不再需要。
    _scheduleAutomaticBackupCheck(viewModel);
    return PopScope(
      // 同步 / 设置页按返回键或侧滑时回到密码库页，而不是退出应用。
      canPop: _tabIndex == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (_tabIndex != 0) setState(() => _tabIndex = 0);
      },
      child: Scaffold(
      appBar: _buildHomeAppBar(viewModel),
      body: Stack(
        children: [
          Column(
          children: [
            if (viewModel.syncProgress case final progress?) ...[
              const LinearProgressIndicator(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: Text(progress),
              ),
            ],
            if (viewModel.webDavConflict)
              MaterialBanner(
                content: const Text('检测到其他设备使用了不同的 WebDAV 配置，本次同步已保留当前设备配置。'),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.push<void>(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const WebDavSettingsScreen(),
                      ),
                    ),
                    child: const Text('检查配置'),
                  ),
                ],
              ),
            Expanded(
              child: IndexedStack(
                index: _tabIndex,
                // 1.2.2：只有三个页面。原来第 2 项是"新建"页，
                // 它既不是页面、又堆满了同步与设置的功能，已整体删除。
                children: [
                  _buildVaultTab(viewModel),
                  _buildSyncTab(viewModel),
                  _buildSettingsTab(viewModel),
                ],
              ),
            ),
          ],
        ),
        ],
      ),
      ),
    );
  }


  // 1.2.2：不再需要 isWideLayout —— 宽屏专属的"新建"按钮已移除，
  // 新建入口改为密码库页内所有屏幕尺寸都可见的固定动作。
  PreferredSizeWidget _buildHomeAppBar(VaultViewModel viewModel) {
    final scheme = Theme.of(context).colorScheme;
    // 1.2.2：三条杠（多选 / 展示密码 / 展示网站 / TOTP / 排序 / 锁定）
    // 只服务于"密码库"列表，因此只在密码库页出现。
    final showQuickMenu = _tabIndex == 0;
    final Widget title = switch (_tabIndex) {
      0 => const VaultBrand(compact: true, showIcon: false),
      1 => const Text('同步'),
      _ => const Text('设置'),
    };
    return AppBar(
      backgroundColor: Colors.transparent,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
      leading: _tabIndex == 0
          ? null
          : IconButton(
              tooltip: '返回密码库',
              icon: const Icon(Icons.arrow_back_rounded),
              onPressed: () => setState(() => _tabIndex = 0),
            ),
      title: title,
      actions: [
        if (viewModel.busy)
          const Padding(
            padding: EdgeInsets.all(16),
            child: SizedBox.square(
              dimension: 20,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ),
        // 1.2.2：AppBar 上的"新建"按钮已移除。
        // 原来它只在宽屏（>=900）出现，手机用户根本看不到新建入口；
        // 现在"新建"作为密码库页内的固定动作，见 vault_home_list.dart 顶部按钮。
        if (showQuickMenu) _buildQuickMenuButton(viewModel),
      ],
    );
  }

  Widget _buildQuickMenuButton(VaultViewModel viewModel) {
    final scheme = Theme.of(context).colorScheme;
    final timeActive = viewModel.sortOrder == VaultSortOrder.time;
    final nameActive = viewModel.sortOrder == VaultSortOrder.name;
    return PopupMenuButton<_VaultMenuAction>(
      key: const Key('vault-hamburger'),
      tooltip: '快速操作',
      icon: const Icon(Icons.menu_rounded),
      // 磨砂玻璃面板 + 黑色描边，与搜索框、卡片保持一致。
      color: Colors.white.withValues(alpha: 0.45),
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: scheme.outlineVariant),
      ),
      onSelected: _handleMenuAction,
      itemBuilder: (_) => [
        PopupMenuItem(
          value: _VaultMenuAction.multiSelect,
          child: const _MenuRow(
            icon: Icons.checklist_rounded,
            label: '多选操作',
          ),
        ),
        PopupMenuItem(
          value: _VaultMenuAction.togglePasswords,
          child: _MenuRow(
            icon: viewModel.showPasswords
                ? Icons.visibility_off_outlined
                : Icons.visibility_outlined,
            label: viewModel.showPasswords ? '隐藏密码' : '展示密码',
            active: viewModel.showPasswords,
          ),
        ),
        PopupMenuItem(
          value: _VaultMenuAction.sortByTime,
          child: _MenuRow(
            icon: timeActive && viewModel.sortReversed
                ? Icons.south_outlined
                : Icons.north_outlined,
            label: timeActive
                ? (viewModel.sortReversed ? '按时间倒序' : '按时间正序')
                : '按时间排序',
            active: timeActive,
          ),
        ),
        PopupMenuItem(
          value: _VaultMenuAction.sortByName,
          child: _MenuRow(
            icon: nameActive && viewModel.sortReversed
                ? Icons.south_outlined
                : Icons.north_outlined,
            label: nameActive
                ? (viewModel.sortReversed ? '按名称倒序' : '按名称正序')
                : '按名称排序',
            active: nameActive,
          ),
        ),
      ],
    );
  }

  Widget _buildVaultTab(VaultViewModel viewModel) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth >= _wideLayoutMinWidth) {
          VaultItem? activeItem;
          for (final item in viewModel.items) {
            if (item.id == _activeItemId) {
              activeItem = item;
              break;
            }
          }
          final listWidth = (constraints.maxWidth * 0.42).clamp(400.0, 480.0);
          return Row(
            children: [
              SizedBox(
                width: listWidth,
                child: _VaultList(
                  viewModel: viewModel,
                  selectedItemId: activeItem?.id,
                  onOpenSync: () => setState(() => _tabIndex = 1),
                  onOpenSettings: () => setState(() => _tabIndex = 2),
                  onItemTap: (item) {
                    setState(() => _activeItemId = item.id);
                  },
                ),
              ),
              const VerticalDivider(width: 1),
              Expanded(
                child: activeItem == null
                    ? Center(
                        child: Text(
                          '选择一个条目，或创建新密码',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      )
                    : _ItemViewer(
                        key: ValueKey(activeItem.id),
                        viewModel: viewModel,
                        item: activeItem,
                        onClose: () {
                          setState(() => _activeItemId = null);
                        },
                        onEdit: () =>
                            _openEditor(context, viewModel, activeItem),
                        onDeleted: () {
                          setState(() => _activeItemId = null);
                        },
                      ),
              ),
            ],
          );
        }
        return _VaultList(
          viewModel: viewModel,
          onOpenSync: () => setState(() => _tabIndex = 1),
          onOpenSettings: () => setState(() => _tabIndex = 2),
        );
      },
    );
  }

  Widget _navigationTile({
    IconData? icon,
    Widget? leading,
    required String title,
    String? subtitle,
    required VoidCallback? onTap,
    Color? iconColor,
  }) {
    return PineVaultSurface(
      margin: const EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.zero,
      radius: PineVaultRadii.md,
      onTap: onTap,
      child: PineVaultListTile(
        icon: icon,
        leading: leading,
        title: title,
        subtitle: subtitle,
        iconColor: iconColor,
        showChevron: true,
      ),
    );
  }

  Widget _switchTile({
    required IconData icon,
    required String title,
    String? subtitle,
    required bool value,
    required ValueChanged<bool>? onChanged,
  }) {
    return PineVaultSurface(
      margin: const EdgeInsets.only(bottom: 10),
      padding: EdgeInsets.zero,
      radius: PineVaultRadii.md,
      child: PineVaultListTile(
        icon: icon,
        title: title,
        subtitle: subtitle,
        trailing: Switch.adaptive(value: value, onChanged: onChanged),
      ),
    );
  }

  Future<void> _pushScreen(Widget screen) {
    return Navigator.push<void>(
      context,
      MaterialPageRoute<void>(builder: (_) => screen),
    );
  }

  /// 设置页「清理缓存」：清掉应用列表 / 图标缓存与已解码图片缓存。
  Future<void> _clearCache(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('清理缓存？'),
        content: const Text('将清除已安装应用列表、应用图标等临时缓存，'
            '密码库数据不受影响。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('清理'),
          ),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;
    await InstalledAppsService.clearCache();
    // 图标是 Image.memory 解码后的位图，缓存一并丢弃，避免仍显示旧图。
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    if (context.mounted) {
      showAppMessage(context, '缓存已清理');
    }
  }


  Widget _buildSyncTab(VaultViewModel viewModel) {
    final theme = Theme.of(context);
    final progress = viewModel.syncProgress;
    final message = viewModel.syncMessage;
    return ListView(
      // 1.2.3：悬浮底栏盖在内容之上，列表按底栏实际高度留出底部余量。
      padding: EdgeInsets.fromLTRB(
        16,
        4,
        16,
        32,
      ),
      children: [
        PineVaultSurface(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const PineVaultIconBadge(
                    icon: Icons.cloud_sync_rounded,
                    size: 46,
                    radius: 15,
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('WebDAV 云同步', style: theme.textTheme.titleMedium),
                        const SizedBox(height: 2),
                        Text(
                          viewModel.busy ? '同步进行中…' : '保持多设备密码一致',
                          style: theme.textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: viewModel.busy
                      ? null
                      : () => _sync(context, viewModel),
                  icon: const Icon(Icons.sync_rounded),
                  label: const Text('立即同步'),
                ),
              ),
              const SizedBox(height: 14),
              // 1.2.5：自动同步周期（1 / 3 / 7 天，默认 3 天）。
              const _AutoSyncIntervalPicker(),
              if (progress != null) ...[
                const SizedBox(height: 12),
                const LinearProgressIndicator(),
                const SizedBox(height: 6),
                Text(progress, style: theme.textTheme.bodySmall),
              ],
              if (message != null) ...[
                const SizedBox(height: 8),
                Text(message, style: theme.textTheme.bodySmall),
              ],
            ],
          ),
        ),
        const PineVaultSectionLabel('同步配置'),
        _navigationTile(
          icon: Icons.cloud_outlined,
          title: 'WebDAV 设置',
          subtitle: '服务器地址、账号与密码',
          onTap: () => _pushScreen(const WebDavSettingsScreen()),
        ),
        _navigationTile(
          icon: Icons.history_rounded,
          title: '同步历史',
          subtitle: '查看最近同步记录',
          onTap: () => _pushScreen(const SyncHistoryScreen()),
        ),
        // 1.2.2：「备份与恢复 / 导入 KDBX / 导出 KDBX / 分组管理」不属于云同步，
        // 已统一收归「设置」页，这里不再重复出现。
      ],
    );
  }

  Widget _buildSettingsTab(VaultViewModel viewModel) {
    return ListView(
      // 1.2.3：悬浮底栏盖在内容之上，列表按底栏实际高度留出底部余量。
      padding: EdgeInsets.fromLTRB(
        16,
        4,
        16,
        32,
      ),
      children: [
        const PineVaultSectionLabel('解锁'),
        _switchTile(
          icon: Icons.fingerprint_rounded,
          title: '生物识别解锁',
          subtitle: viewModel.deviceUnlockSupported
              ? (viewModel.deviceUnlockEnabled ? '已开启' : '未开启')
              : '当前设备不支持',
          value: viewModel.deviceUnlockEnabled,
          onChanged: (viewModel.deviceUnlockSupported &&
                  !viewModel.deviceUnlockBusy)
              ? (value) =>
                  _handleMenu(context, _VaultMenuAction.deviceUnlock)
              : null,
        ),
        _navigationTile(
          icon: Icons.password_rounded,
          title: '修改主密码',
          subtitle: '更新解锁保险库的主密码',
          onTap: () =>
              _handleMenu(context, _VaultMenuAction.changeMasterPassword),
        ),
        // 1.2.2：「WebDAV 设置 / 同步历史」属于云同步，只在「同步」页出现。
        const PineVaultSectionLabel('数据'),
        _navigationTile(
          icon: Icons.settings_backup_restore_rounded,
          title: '备份与恢复',
          subtitle: '本地备份管理与恢复',
          onTap: () => _pushScreen(const BackupScreen()),
        ),
        _navigationTile(
          icon: Icons.delete_outline_rounded,
          title: '回收站',
          subtitle: '找回或彻底删除最近删除的条目',
          onTap: () => _pushScreen(const TrashScreen()),
        ),
        _navigationTile(
          icon: Icons.folder_open_outlined,
          title: '存储路径',
          subtitle: '查看密码库、备份与云端文件的实际位置',
          onTap: () => _pushScreen(const StoragePathsScreen()),
        ),
        _navigationTile(
          icon: Icons.cleaning_services_outlined,
          title: '清理缓存',
          subtitle: '清除应用列表与图标等临时缓存',
          onTap: () => _clearCache(context),
        ),
        const PineVaultSectionLabel('背景'),
        _navigationTile(
          icon: Icons.wallpaper_rounded,
          title: '自定义背景',
          subtitle: AppPreferences.instance.backgroundEnabled
              ? '已设置，点击更换图片'
              : '未设置，点击选择图片',
          onTap: () => _pickBackground(context),
        ),
        if (AppPreferences.instance.backgroundPath != null)
          _navigationTile(
            icon: Icons.hide_image_outlined,
            title: '移除背景',
            subtitle: '恢复默认纯色背景',
            onTap: () => _removeBackground(context),
          ),
        _navigationTile(
          icon: Icons.blur_on_rounded,
          title: '自定义模糊',
          subtitle:
              '当前 ${AppPreferences.instance.backgroundBlur.toStringAsFixed(0)}',
          onTap: () => _editBackgroundBlur(context),
        ),
        const PineVaultSectionLabel('关于'),
        PineVaultSurface(
          margin: const EdgeInsets.only(bottom: 10),
          padding: EdgeInsets.zero,
          radius: PineVaultRadii.md,
          // 只保留图标与版本号：不含软件名、不含「历史版本」入口。
          // 版本号需与 pubspec.yaml 的 version 保持一致。
          child: const PineVaultListTile(
            icon: Icons.info_outline_rounded,
            title: '版本 1.1.1',
          ),
        ),
      ],
    );
  }

  /// 设置页「自定义模糊」：用底部弹窗的滑块调整背景模糊半径。
  Future<void> _editBackgroundBlur(BuildContext context) async {
    var value = AppPreferences.instance.backgroundBlur.clamp(0.0, 30.0);
    final result = await showModalBottomSheet<double>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                '自定义模糊',
                style: Theme.of(sheetContext).textTheme.titleLarge,
              ),
              const SizedBox(height: 4),
              Text(
                '模糊半径 ${value.toStringAsFixed(0)}（0 为不模糊）',
                style: Theme.of(sheetContext).textTheme.bodyMedium,
              ),
              Slider(
                value: value,
                min: 0,
                max: 30,
                divisions: 30,
                label: value.toStringAsFixed(0),
                onChanged: (next) => setSheetState(() => value = next),
              ),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: () => Navigator.pop(sheetContext, value),
                child: const Text('保存'),
              ),
            ],
          ),
        ),
      ),
    );
    if (result == null) return;
    await AppPreferences.instance.setBackgroundBlur(result);
    if (mounted) setState(() {});
  }

  /// 设置页「自定义背景」：选一张图片复制进应用私有目录并立即生效。
  Future<void> _pickBackground(BuildContext context) async {
    try {
      final file = await FilePicker.pickFile(
        dialogTitle: '选择背景图片',
        type: FileType.image,
      );
      if (file == null) return;
      final path = file.path;
      if (path == null) return;
      await AppPreferences.instance.importBackgroundImage(path);
      if (mounted) setState(() {});
    } catch (error) {
      if (mounted) showAppMessage(context, '设置背景失败：$error');
    }
  }

  /// 移除自定义背景，恢复默认纯色底。
  Future<void> _removeBackground(BuildContext context) async {
    await AppPreferences.instance.clearBackground();
    if (mounted) setState(() {});
  }

  void _schedulePendingSaveRefresh(VaultViewModel viewModel) {
    if (!_pendingSaveRefreshCheck ||
        viewModel.state != VaultAppState.unlocked) {
      return;
    }
    _pendingSaveRefreshCheck = false;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted || !await NativeAutofillService.hasPendingSaveRefresh()) {
        return;
      }
      final refreshed = await viewModel.reloadAfterAutofillSave();
      if (refreshed) {
        await NativeAutofillService.clearPendingSaveRefresh();
      }
    });
  }

  void _scheduleAutomaticBackupCheck(VaultViewModel viewModel) {
    if (_automaticBackupChecked ||
        _automaticBackupCheckScheduled ||
        viewModel.state != VaultAppState.unlocked) {
      return;
    }
    _automaticBackupCheckScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final backupViewModel = context.read<BackupViewModel>();
      final checked = await backupViewModel.checkAutomatic();
      if (!mounted) return;
      setState(() {
        _automaticBackupCheckScheduled = false;
        _automaticBackupChecked = checked;
      });
      final message = backupViewModel.message;
      if (checked && message != null) {
        showAppMessage(context, message);
      }
    });
  }

  Future<void> _handleMenuAction(_VaultMenuAction action) async {
    if (action == _VaultMenuAction.autofill) {
      await _toggleAutofill();
      return;
    }
    if (!mounted) return;
    await _handleMenu(context, action);
  }

  Future<void> _refreshAutofillStatus() async {
    if (!NativeAutofillService.isSupported) return;
    try {
      final status = await Future.wait([
        NativeAutofillService.isEnabled(),
        NativeAutofillService.isBackgroundAllowed(),
      ]);
      if (mounted) {
        setState(() {
          _autofillEnabled = status[0];
          _autofillBackgroundAllowed = status[1];
        });
      }
    } on PlatformException {
      if (mounted) {
        setState(() {
          _autofillEnabled = false;
          _autofillBackgroundAllowed = false;
        });
      }
    }
  }

  Future<void> _toggleAutofill() async {
    if (_autofillBusy) return;
    setState(() => _autofillBusy = true);
    try {
      if (_autofillEnabled && !_autofillBackgroundAllowed) {
        await NativeAutofillService.requestBackgroundAccess();
      } else if (_autofillEnabled) {
        await NativeAutofillService.disable();
      } else {
        await NativeAutofillService.enable();
      }
      await _refreshAutofillStatus();
    } on PlatformException {
      if (mounted) showAppMessage(context, '无法打开自动填充设置');
    } finally {
      if (mounted) setState(() => _autofillBusy = false);
    }
  }
}

enum _VaultMenuAction {
  sync,
  webDav,
  history,
  backup,
  groupManagement,
  changeMasterPassword,
  deviceUnlock,
  autofill,
  multiSelect,
  lock,
  togglePasswords,
  toggleWebsites,
  toggleTotp,
  sortByTime,
  sortByName,
}

class _MenuRow extends StatelessWidget {
  const _MenuRow({
    required this.icon,
    required this.label,
    this.active = false,
  });

  final IconData icon;
  final String label;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final color = active ? Theme.of(context).colorScheme.primary : null;
    return Row(
      children: [
        Icon(icon, color: color),
        const SizedBox(width: 12),
        Text(label, style: color == null ? null : TextStyle(color: color)),
      ],
    );
  }
}

Future<void> _handleMenu(BuildContext context, _VaultMenuAction action) async {
  final viewModel = context.read<VaultViewModel>();
  switch (action) {
    case _VaultMenuAction.sync:
      await _sync(context, viewModel);
    case _VaultMenuAction.webDav:
      await Navigator.push<void>(
        context,
        MaterialPageRoute(builder: (_) => const WebDavSettingsScreen()),
      );
    case _VaultMenuAction.history:
      await Navigator.push<void>(
        context,
        MaterialPageRoute(builder: (_) => const SyncHistoryScreen()),
      );
    case _VaultMenuAction.backup:
      await Navigator.push<void>(
        context,
        MaterialPageRoute(builder: (_) => const BackupScreen()),
      );
    case _VaultMenuAction.groupManagement:
      await _showGroupManagement(context, viewModel);
    case _VaultMenuAction.changeMasterPassword:
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.transparent,
        builder: (_) => const ChangeMasterPasswordDialog(),
      );
    case _VaultMenuAction.deviceUnlock:
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.transparent,
        builder: (_) =>
            DeviceUnlockSheet(disable: viewModel.deviceUnlockEnabled),
      );
    case _VaultMenuAction.autofill:
      break;
    case _VaultMenuAction.multiSelect:
      viewModel.startSelectionMode();
    case _VaultMenuAction.lock:
      viewModel.lock();
    case _VaultMenuAction.togglePasswords:
      viewModel.setShowPasswords(!viewModel.showPasswords);
    case _VaultMenuAction.toggleWebsites:
      viewModel.setShowWebsites(!viewModel.showWebsites);
    case _VaultMenuAction.toggleTotp:
      viewModel.setShowTotp(!viewModel.showTotp);
    case _VaultMenuAction.sortByTime:
      viewModel.setSortOrder(VaultSortOrder.time);
    case _VaultMenuAction.sortByName:
      viewModel.setSortOrder(VaultSortOrder.name);
  }
}

/// 1.2.5：「自动同步周期」选择器（1 天 / 3 天 / 7 天，默认 3 天）。
///
/// 自动同步不再由「解锁 / 重新登录 / 新增修改密码」触发，只在周期到达后执行；
/// 「立即同步」按钮不受周期限制。
class _AutoSyncIntervalPicker extends StatefulWidget {
  const _AutoSyncIntervalPicker();

  @override
  State<_AutoSyncIntervalPicker> createState() => _AutoSyncIntervalPickerState();
}

class _AutoSyncIntervalPickerState extends State<_AutoSyncIntervalPicker> {
  Future<void> _select(int days) async {
    if (days == AppPreferences.instance.autoSyncIntervalDays) return;
    await AppPreferences.instance.setAutoSyncIntervalDays(days);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final int current = AppPreferences.instance.autoSyncIntervalDays;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                '自动同步周期',
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            for (final int days in AppPreferences.autoSyncIntervalOptions)
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: _option(context, days, days == current),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          '记忆只在周期到达后与云端同步（默认 3 天）；'
          '解锁、新增或修改密码时不再立即同步，需要时点「立即同步」。',
          style: theme.textTheme.bodySmall,
        ),
      ],
    );
  }

  Widget _option(BuildContext context, int days, bool selected) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: () => _select(days),
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? scheme.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: selected ? scheme.primary : scheme.outlineVariant,
          ),
        ),
        child: Text(
          '$days 天',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: selected ? scheme.onPrimary : scheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}
